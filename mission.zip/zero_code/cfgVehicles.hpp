class CfgVehicles
{
	class Animal;
	class Pastor;
	class Fin;
	class DZAnimal: Animal
	{
		scope = 0;
		side = 1;
		accuracy = 0.25;
		boneHead = "head";
		bonePrimaryWeapon = "head";
		triggerAnim = "";
		picture = "";
		icon = "\Ca\animals2\data\mapicon_animals_ca.paa";
		mapSize = 10;
		weaponSlots = 0;
		fsmFormation = "";
		fsmDanger = "";
		agentTasks[] = {};
		moves = "CfgMovesAnimal";
		memoryPointHeadAxis = "head_axis";
		woman = 0;
		faceType = "Default";
		boneLEye = "l_eye";
		boneREye = "r_eye";
		boneLEyelidUp = "eye_upl";
		boneREyelidUp = "eye_upr";
		boneLEyelidDown = "eye_lwl";
		boneREyelidDown = "eye_lwr";
		boneLPupil = "l_pupila";
		boneRPupil = "r_pupila";
		memoryPointAim = "aimPoint";
		memoryPointCameraTarget = "camera";
		extCameraPosition[] = {0,0.5,-2.5};
		class EventHandlers{};
		class Wounds
		{
			tex[] = {};
			mat[] = {};
		};
		class VariablesScalar {};
		class VariablesString {};
	};

	class DZ_Pastor : Pastor
	{
		scope = 2;
		side = 1;
		model = "\ca\animals2\Dogs\Pastor\Pastor";
		displayName = "Alsatian";
		moves = "CfgMovesDogDZ";
		gestures = "CfgGesturesDogDZ";
		fsmDanger = "";
		fsmFormation = "";
		agentTasks[] = {};
		woman = 0;
		class EventHandlers{};
		class Wounds
		{
			tex[] = {};
			mat[] = {};
		};
		class VariablesScalar {};
		class VariablesString {};
	};

	class DZ_Fin : Fin
	{
		scope = 2;
		side = 1;
		model = "\ca\animals2\Dogs\Fin\Fin";
		displayName = "Fin";
		moves = "CfgMovesDogDZ";
		gestures = "CfgGesturesDogDZ";
		fsmDanger = "";
		fsmFormation = "";
		agentTasks[] = {};
		woman = 0;
		class EventHandlers{};
		class Wounds
		{
			tex[] = {};
			mat[] = {};
		};
		class VariablesScalar {};
		class VariablesString {};
	};

	class Soldier_Crew_PMC;
	class Survivor1_DZ : Soldier_Crew_PMC
	{
		displayName = $STR_CHAR_1;
		side = TWest;
		weapons[] = {"Throw","Put","Flare","Loot"};
		model = "\zero\objects\proxy_man";
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = 1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072;
		canHideBodies = true;
	};

	class Survivor2_DZ : Soldier_Crew_PMC
	{
		displayName = $STR_CHAR_1;
		side = TWest;
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		model = "\zero\characters\man_survivor";
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = 1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072;
		canHideBodies = true;
	};

	class Hero1_DZ : Survivor2_DZ
	{
		model = "\zero\characters\man_hero";
		HiddenSelections[] = {"camo1", "camo2", "camo3"};
		HiddenSelectionsTextures[] = {"ca\characters_pmc\pmc_soldier\data\bauer_co.paa", "ca\characters_pmc\pmc_soldier\data\bauer_gear_co.paa", "ca\characters_pmc\pmc_soldier\data\headgear_co.paa"};

		class EventHandlers
		{
			init = "(_this select 0) setObjectTexture [0,[""\Ca\Characters_PMC\PMC_soldier\Data\bauer_2_co.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\bauer_3_co.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\bauer_4_co.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\bauer_5_co.paa""] select floor random 4]; (_this select 0) setObjectTexture [1,[""ca\characters_pmc\pmc_soldier\data\bauer_gear_co.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\Bauer_Gear_1_co.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\Bauer_Gear_2_co.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\Bauer_Gear_3_co.paa""] select floor random 4]; (_this select 0) setObjectTexture [2,[""\Ca\Characters_PMC\PMC_soldier\Data\HeadGear_CO.paa"",""\Ca\Characters_PMC\PMC_soldier\Data\HeadGear_1_CO.paa""] select floor random 2]";
		};
	};

	class SurvivorW2_DZ : Soldier_Crew_PMC
	{
		displayName = $STR_CHAR_1;
		side = TWest;
		weapons[] = {"Throw","Put","Flare","Loot"};
		model = "\zero\characters\annie_original";
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = 1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072;
		canHideBodies = true;
		identityTypes[] = {"Language_W_EN_EP1", "Woman"};
		languages[] = {"EN"};

		class TalkTopics
		{
			core = "Core_E";
			core_en = "Core_Full_E";
		};
		genericNames = "EnglishWomen";

		class SpeechVariants
		{
			class Default
			{
				speechSingular[] = {"veh_woman"};
				speechPlural[] = {"veh_women"};
			};

			class EN : Default {};

			class CZ
			{
				speechSingular[] = {"veh_woman_CZ"};
				speechPlural[] = {"veh_women_CZ"};
			};

			class CZ_Akuzativ
			{
				speechSingular[] = {"veh_woman_CZ4P"};
				speechPlural[] = {"veh_women_CZ4P"};
			};

			class RU
			{
				speechSingular[] = {"veh_woman_RU"};
				speechPlural[] = {"veh_women_RU"};
			};
		};
		TextPlural = "Women";
		TextSingular = "Woman";
		nameSound = "veh_woman";

		class HitDamage
		{
			class Group0
			{
				hitSounds[] = {{{"ca\sounds\Characters\Noises\Damage\banz-hit-01", 0.177828, 1, 120}, 0.2}, {{"ca\sounds\Characters\Noises\Damage\banz-hit-02", 0.177828, 1, 120}, 0.2}, {{"ca\sounds\Characters\Noises\Damage\banz-hit-03", 0.177828, 1, 120}, 0.2}, {{"ca\sounds\Characters\Noises\Damage\banz-hit-04", 0.177828, 1, 120}, 0.1}, {{"ca\sounds\Characters\Noises\Damage\banz-hit-05", 0.177828, 1, 120}, 0.1}, {{"ca\sounds\Characters\Noises\Damage\banz-hit-06", 0.177828, 1, 120}, 0.1}, {{"ca\sounds\Characters\Noises\Damage\banz-hit-07", 0.177828, 1, 120}, 0.1}};
				damageSounds[] = {{"body", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-01", 0.0562341, 1, 120, 0.25, 5, 6, 10}}, {"body", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-02", 0.0562341, 1, 120, 0.25, 5, 7.5, 10}}, {"body", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-03", 0.0562341, 1, 120, 0.25, 5, 6, 10}}, {"body", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-04", 0.0562341, 1, 120, 0.25, 5, 7.5, 10}}, {"hands", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-07-arm", 0.0562341, 1, 120, 0.5, 0, 2.5, 5}}, {"hands", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-08-arm", 0.0562341, 1, 120, 0.5, 0, 2.5, 5}}, {"legs", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-05-leg", 0.0562341, 1, 120, 0.5, 0, 1, 2}}, {"legs", {"ca\sounds\Characters\Noises\Damage\banz-damage-g1-06-leg", 0.0562341, 1, 120, 0.5, 0, 1, 2}}};
			};
		};

		class SoundBreath
		{
			breath0[] = {{{{"\ca\sounds\Characters\Noises\Breath\hanz-run-breath-01", 0.0562341, 1, 8}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-run-breath-02", 0.0562341, 1, 8}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-run-breath-03", 0.0562341, 1, 8}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-run-breath-04", 0.125893, 1, 8}, 0.25}}, {{{"\ca\sounds\Characters\Noises\Breath\hanz-run2-breath-01", 0.0562341, 1, 15}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-run2-breath-02", 0.0562341, 1, 15}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-run2-breath-03", 0.0562341, 1, 15}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-run2-breath-04", 0.125893, 1, 15}, 0.25}}, {{{"\ca\sounds\Characters\Noises\Breath\hanz-sprint-breath-01", 0.1, 1, 20}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-sprint-breath-02", 0.1, 1, 20}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-sprint-breath-03", 0.1, 1, 20}, 0.25}, {{"\ca\sounds\Characters\Noises\Breath\hanz-sprint-breath-04", 0.1, 1, 20}, 0.25}}};
		};

		class SoundGear
		{
			primary[] = {{"walk", {"", 0.00177828, 1, 10}}, {"run", {"", 0.00316228, 1, 15}}, {"sprint", {"", 0.00562341, 1, 20}}};
			secondary[] = {{"walk", {"", 0.00177828, 1, 10}}, {"run", {"", 0.00316228, 1, 10}}, {"sprint", {"", 0.00562341, 1, 10}}};
		};

		class SoundEquipment
		{
			soldier[] = {{"walk", {"", 0.00177828, 1, 13}}, {"run", {"", 0.00316228, 1, 20}}, {"sprint", {"", 0.00398107, 1, 25}}};
			civilian[] = {{"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-01", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-02", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-03", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-04", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-05", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-06", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-07", 0.177828, 1, 8}}, {"walk", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-walk-08", 0.177828, 1, 8}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-01", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-02", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-03", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-04", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-05", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-06", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-07", 0.1, 1, 15}}, {"run", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-run-08", 0.1, 1, 15}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-01", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-02", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-03", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-04", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-05", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-06", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-07", 0.0562341, 1, 20}}, {"sprint", {"\ca\sounds\Characters\Noises\Equipment\civil-equipment-sprint-08", 0.0562341, 1, 20}}};
		};
		hiddenSelections[] = {};
	};

	class BanditW1_DZ : SurvivorW2_DZ
	{
		side = TWest;
		model = "\zero\characters\woman_bandit";
	};

	class Bandit1_DZ : Soldier_Crew_PMC
	{
		displayName = "$STR_CHAR_2";
		side = 1;
		hiddenselectionstextures[] = {};
		model = "\ca\characters_E\GER\GER_rifleman";
		portrait = "\Ca\characters_E\data\portraits\ger_soldier_CA";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		backpack = "";
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};
	class Hunter1_DZ: Soldier_Crew_PMC
	{
		displayName = "Hunter";
		side = 1;
		hiddenselections[] = {};
		hiddenselectionstextures[] = {};
		model = "\ca\characters2\Ghillie_Top";
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class ZERO_WEST_DE1 : Soldier_Crew_PMC
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		hiddenselectionstextures[] = {};
		model = "\ksk_mod\GER_rifleman_wdl";
		portrait = "\Ca\characters_E\data\portraits\ger_soldier_CA";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		backpack = "";
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};
	class ZERO_WEST_DE2 : Soldier_Crew_PMC
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		hiddenselectionstextures[] = {};
		model = "\ksk_mod\GER_rifleman_light_wdl";
		portrait = "\Ca\characters\data\portraits\comBarHead_opFor_ca";
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class BAF_Soldier_L_W;
	class ZERO_WEST_UK1: BAF_Soldier_L_W
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class BAF_Soldier_W;
	class ZERO_WEST_UK2: BAF_Soldier_W
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class BAF_Soldier_SniperH_W;
	class ZERO_WEST_GHILLE: BAF_Soldier_SniperH_W
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		hiddenselectionstextures[] = {"\ca\characters2\data\ghillie_overall1_co.paa"};
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};
	class ZERO_EAST_GHILLE: BAF_Soldier_SniperH_W
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		hiddenselectionstextures[] = {"\ca\characters2\data\ghillie_overall2_co.paa"};
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_M_GL1;
	class ZERO_WEST_US1: DZero_ARD_TSF_M_GL1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_M_MD1;
	class ZERO_WEST_US2: DZero_ARD_TSF_M_MD1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CHT_TL1;
	class ZERO_CDF1: DZero_ARD_TSF_CHT_TL1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CHT_RM1;
	class ZERO_CDF2: DZero_ARD_TSF_CHT_RM1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CHT_MD1;
	class ZERO_CDF3: DZero_ARD_TSF_CHT_MD1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CHT_MG1;
	class ZERO_CDF4: DZero_ARD_TSF_CHT_MG1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CHT_GL1;
	class ZERO_CDF5: DZero_ARD_TSF_CHT_GL1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_FSB_KZS_GL;
	class ZERO_FSB1: DZero_SG_FSB_KZS_GL
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_FSB_KZS_AT;
	class ZERO_FSB2: DZero_SG_FSB_KZS_AT
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_FSB_Gorka_OP;
	class ZERO_FSB3: DZero_SG_FSB_Gorka_OP
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_FSB_Gorka_MG;
	class ZERO_FSB4: DZero_SG_FSB_Gorka_MG
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_GRU_scout;
	class ZERO_GRU1: DZero_SG_GRU_scout
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_GRU_Operator_W;
	class ZERO_GRU2: DZero_SG_GRU_Operator_W
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_SG_GRU_Operator_D;
	class ZERO_GRU3: DZero_SG_GRU_Operator_D
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CTU_GL1;
	class ZERO_NICE1: DZero_ARD_TSF_CTU_GL1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class DZero_ARD_TSF_CTD_GL1;
	class ZERO_MEAN1: DZero_ARD_TSF_CTD_GL1
	{
		displayName = "$STR_CHAR_1";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class BAF_Soldier_Officer_W;
	class ZERO_CREW: BAF_Soldier_Officer_W
	{
		displayName = "Officer";
		side = 1;
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class ZERO_PILOT_US: Soldier_Crew_PMC
	{
		displayName = "Pilot";
		side = 1;
		hiddenselections[] = {};
		hiddenselectionstextures[] = {};
		model = "\ca\characters2\USMC\usmc_soldier_pilot";
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class ZERO_PILOT_RU: Soldier_Crew_PMC
	{
		displayName = "Pilot";
		side = 0;
		hiddenselections[] = {};
		hiddenselectionstextures[] = {};
		model = "\ca\characters2\Rus\Soldier_Pilot";
		backpack = "";
		weapons[] = {"Throw","Put","Flare","Loot"};
		magazines[] = {};
		respawnWeapons[] = {"Throw","Put","Flare","Loot"};
		respawnMagazines[] = {};
		weaponSlots = "1	 + 	4	 + 12*		256	 + 2*	4096	 + 	2	 + 8*	16  + 12*131072";
		canHideBodies = true;
	};

	class ReammoBox_EP1;
	class Bag_Base_EP1: ReammoBox_EP1
	{
		scope = 0;
		transportMaxMagazines = 0;
		transportMaxWeapons = 0;
		isbackpack = 1;
		reversed = true;
		vehicleClass = "Backpacks";

		class TransportMagazines {};
		class TransportWeapons {};
		class DestructionEffects {};

		class eventHandlers
		{
			init = "(_this select 0) execVM '\z\addons\zero_code\init\object_takeBackpackAction.sqf';";
		};
	};

	class DZ_Patrol_Pack_EP1: Bag_Base_EP1
	{
		scope = 2;
		displayName = "Patrol Pack (Coyote)";
		descriptionshort = "Backpack <br/>Spaces: 8<br/> Weapon Slots: 1";
		picture = "\ca\weapons_e\data\icons\backpack_US_ASSAULT_COYOTE_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapsize = 2;
		model = "\ca\weapons_e\AmmoBoxes\backpack_us_assault_Coyote.p3d";
		transportMaxWeapons = 1;
		transportMaxMagazines = 8;
	};

	class DZ_Assault_Pack_EP1: Bag_Base_EP1
	{
		scope = 2;
		displayName = "Assault Pack (ACU)";
		descriptionshort = "Backpack <br/>Spaces: 12<br/> Weapon Slots: 1";
		picture = "\ca\weapons_e\data\icons\backpack_US_ASSAULT_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapSize = 2;
		model = "\ca\weapons_e\AmmoBoxes\backpack_us_assault.p3d";
		transportMaxWeapons = 1;
		transportMaxMagazines = 12;
	};

	class DZ_Czech_Vest_Puch: Bag_Base_EP1
	{
		displayname = "Czech Vest Pouch";
		descriptionshort = "Backpack <br/>Spaces: 12<br/> Weapon Slots: 0";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapsize = 2;
		model = "\ca\weapons_e\AmmoBoxes\backpack_acr_small.p3d";
		picture = "\ca\weapons_e\data\icons\backpack_ACR_small_CA.paa";
		scope = 2;
		transportmaxmagazines = 12;
		transportmaxweapons = 0;
	};

	class DZ_ALICE_Pack_EP1: Bag_Base_EP1
	{
		scope = 2;
		displayName = "ALICE Pack";
		descriptionshort = "Backpack <br/>Spaces: 16<br/> Weapon Slots: 2";
		picture = "\ca\weapons_e\data\icons\backpack_TK_ALICE_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapsize = 2;
		model = "\ca\weapons_e\AmmoBoxes\backpack_tk_alice.p3d";
		transportMaxWeapons = 2;
		transportMaxMagazines = 16;
	};

	class DZ_TK_Assault_Pack_EP1 : Bag_Base_EP1
	{
		scope = 2;
		displayName = "Survival ACU";
		descriptionshort = "Backpack <br/>Spaces: 16<br/> Weapon Slots: 2";
		mapSize = 2;
		picture = "\ca\weapons_e\data\icons\backpack_CIVIL_ASSAULT_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		model = "\ca\weapons_e\AmmoBoxes\backpack_civil_assault.p3d";
		transportMaxWeapons = 2;
		transportMaxMagazines = 16;
	};

	class DZ_British_ACU : Bag_Base_EP1
	{
		scope = 2;
		displayName = "British Assault Pack";
		descriptionshort = "Backpack <br/>Spaces: 18<br/> Weapon Slots: 3";
		mapSize = 2;
		model = "\ca\weapons_baf\Backpack_Small_BAF";
		picture = "\ca\weapons_baf\data\UI\backpack_BAF_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		transportMaxWeapons = 3;
		transportMaxMagazines = 18;
	};

	class DZ_CivilBackpack_EP1: Bag_Base_EP1
	{
		scope = 2;
		displayName = "Czech Backpack";
		descriptionshort = "Backpack <br/>Spaces: 24<br/> Weapon Slots: 4";
		picture = "\ca\weapons_e\data\icons\backpack_ACR_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapsize = 2;
		model = "\ca\weapons_e\AmmoBoxes\backpack_acr.p3d";
		transportMaxWeapons = 4;
		transportMaxMagazines = 24;
	};

	class DZ_Backpack_EP1: Bag_Base_EP1
	{
		scope = 2;
		displayName = "Backpack (Coyote)";
		descriptionshort = "Backpack <br/>Spaces: 24<br/> Weapon Slots: 6";
		picture = "\ca\weapons_e\data\icons\backpack_US_CA.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapsize = 2;
		model = "\ca\weapons_e\AmmoBoxes\backpack_us.p3d";
		transportMaxWeapons = 6;
		transportMaxMagazines = 24;
	};

	class DZ_Backpack_WL: Bag_Base_EP1
	{
		scope = 2;
		displayName = "Backpack (Woodland)";
		descriptionshort = "Backpack <br/>Spaces: 24<br/> Weapon Slots: 6";
		picture = "\ksk_mod\backpack_wdl_ca.paa";
		icon = "\ca\weapons_e\data\icons\mapIcon_backpack_CA.paa";
		mapsize = 2;
		model = "\ksk_mod\backpack_ger_wdl.p3d";
		transportMaxWeapons = 6;
		transportMaxMagazines = 24;
	};

	class Air;
	class Helicopter: Air
	{
		class Turrets
		{
			class MainTurret;
		};
		class NewTurret;
		class AnimationSources;
		class HitPoints
		{
			class HitGlass1;
			class HitGlass2;
			class HitGlass3;
			class HitGlass4;
			class HitGlass5;
		};
	};
	class UH60_Base: Helicopter {};
	class ZERO_MH60S: UH60_Base
	{
		radartype = 0;
		accuracy = 1.5;
		armor = 35;
		cargoaction[] = {"UH60_Cargo01", "UH1Y_Cargo02", "UH1Y_Cargo01", "UH1Y_Cargo01", "UH1Y_Cargo01", "UH60_Cargo02"};
		cargocompartments[] = {"Compartment2"};
		cargoiscodriver[] = {1, 0, 0};
		castcargoshadow = 1;
		castdrivershadow = 1;
		cost = "1e+007";
		crew = "ZERO_PILOT_US";
		damageresistance = 0.00242;
		destrtype = "DestructWreck";
		displayname = "MH-60S";
		driveraction = "UH60_Pilot";
		drivercompartments = "Compartment1";
		driverinaction = "UH60_Pilot";
		enablemanualfire = 0;
		enablesweep = 0;
		faction = "USMC";
		forcehidedriver = 1;
		icon = "\ca\air\data\map_ico\icomap_MH60mg_CA.paa";
		initcargoangley = 10;
		mainrotorspeed = -1;
		mapsize = 17;
		maxcargoangley = 120;
		maxspeed = 250;
		mincargoangley = -60;
		model = "\ca\air\Mh_60mg";
		picture = "\ca\air\data\ico\MH_60mg_CA.paa";
		scope = 2;
		side = 1;
		sounddammage[] = {"\ca\Air\Data\Sound\alarm_loop1", 0.001, 1};
		soundengineoffext[] = {"ca\sounds\Air\UH1Y\ext\ext-motor-stop", 1, 1, 800};
		soundengineoffint[] = {"ca\sounds\Air\UH1Y\int\int-stop-final", 0.1, 1};
		soundengineonext[] = {"ca\sounds\Air\UH1Y\ext\ext-motor-start", 1, 1, 800};
		soundengineonint[] = {"ca\sounds\Air\UH1Y\int\int-start-final", 0.1, 1};
		soundenviron[] = {"", 0.0316228, 1};
		soundgetin[] = {"\ca\Sounds\Air\Noises\heli_door_01", 0.316228, 1};
		soundgetout[] = {"\ca\Sounds\Air\Noises\heli_door_01", 0.316228, 1, 30};
		supplyradius = 2.5;
		threat[] = {0.3, 1, 0.4};
		transportammo = 0;
		transportmaxbackpacks = 10;
		transportmaxmagazines = 150;
		transportmaxweapons = 30;
		transportsoldier = 13;
		type = 2;
		typicalcargo[] = {};
		vehicleclass = "Air";
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
		class Sounds
		{
			class Engine
			{
				frequency = "rotorSpeed";
				sound[] = {"ca\sounds\air\uh1y\ext\ext-fly-mode2", 2.51189, 1, 900};
				volume = "camPos*((rotorSpeed-0.72)*4)";
			};
			class RotorLowOut
			{
				cone[] = {1.6, 3.14, 2, 0.5};
				frequency = "rotorSpeed";
				sound[] = {"ca\sounds\air\uh1y\int\int-rotor-single5b", 2.51189, 1, 1400};
				volume = "camPos*(0 max (rotorSpeed-0.1))";
			};
			class RotorHighOut
			{
				cone[] = {1.6, 3.14, 2, 0.5};
				frequency = "rotorSpeed";
				sound[] = {"ca\sounds\air\uh1y\int\int-rotor-single5a", 2.51189, 1, 1600};
				volume = "camPos*10*(0 max (rotorThrust-0.9))";
			};
			class EngineIn
			{
				frequency = "rotorSpeed";
				sound[] = {"ca\sounds\air\uh1y\int\int-fly-mode7", 3.16228, 1};
				volume = "(1-camPos)*((rotorSpeed-0.75)*4)";
			};
			class RotorLowIn
			{
				frequency = "rotorSpeed";
				sound[] = {"ca\sounds\air\uh1y\int\int-rotor-single5b", 3.16228, 1};
				volume = "2*(1-camPos)*((rotorSpeed factor[0.3, 1.1]) min (rotorSpeed factor[1.1, 0.3]))";
			};
			class RotorHighIn
			{
				frequency = "rotorSpeed";
				sound[] = {"ca\sounds\air\uh1y\int\int-rotor-single5a", 3.16228, 1};
				volume = "(1-camPos)*3*(rotorThrust-0.9)";
			};
		};
		class AnimationSources: AnimationSources
		{
			class ReloadAnim
			{
				source = "reload";
				weapon = "M240_veh";
			};
			class ReloadMagazine
			{
				source = "reloadmagazine";
				weapon = "M240_veh";
			};
			class Revolving
			{
				source = "revolving";
				weapon = "M240_veh";
			};
			class ReloadAnim_2
			{
				source = "reload";
				weapon = "M240_veh_2";
			};
			class ReloadMagazine_2
			{
				source = "reloadmagazine";
				weapon = "M240_veh_2";
			};
			class Revolving_2
			{
				source = "revolving";
				weapon = "M240_veh_2";
			};
		};
		class Library
		{
			libtextdesc = "The Knighthawk is a US NAVY utility helicopter used for transport roles, medical evacuation and even air support.<br />It is capable of carrying 11 combat equipped soldiers. Easy to maintain in the field.";
		};
		class Damage
		{
			mat[] = {"ca\air\Data\uh60_skla.rvmat", "ca\air\Data\uh60_skla_damage.rvmat", "ca\air\Data\uh60_skla_damage.rvmat", "ca\air\Data\uh60_skla_in.rvmat", "ca\air\Data\uh60_skla_in_damage.rvmat", "ca\air\Data\uh60_skla_in_damage.rvmat", "ca\air\Data\materialy\uh60_01.rvmat", "ca\air\Data\materialy\uh60_01_damage.rvmat", "ca\air\Data\materialy\uh60_01_destruct.rvmat"};
			tex[] = {};
		};
		class Turrets: Turrets
		{
			class MainTurret: MainTurret
			{
				body = "mainTurret";
				gun = "mainGun";
				gunbeg = "muzzle_1";
				gunend = "chamber_1";
				gunneraction = "MH60_Gunner";
				gunnercompartments = "Compartment2";
				gunnerinaction = "MH60_Gunner";
				gunnername = "crew chief";
				gunneropticsmodel = "\ca\weapons\optika_empty";
				gunneropticsshowcursor = 1;
				gunneroutopticsshowcursor = 1;
				initelev = -80;
				initturn = 90;
				magazines[] = {"100Rnd_762x51_M240", "100Rnd_762x51_M240", "100Rnd_762x51_M240"};
				maxelev = 25;
				maxturn = 150;
				minelev = -80;
				minturn = 30;
				primarygunner = 1;
				soundservo[] = {"", 0.01, 1};
				stabilizedinaxes = "StabilizedInAxesNone";
				weapons[] = {"M240_veh"};
				class ViewOptics
				{
					initanglex = 0;
					initangley = 0;
					initfov = 0.7;
					maxanglex = 30;
					maxangley = 100;
					maxfov = 1.1;
					minanglex = -30;
					minangley = -100;
					minfov = 0.25;
				};
			};
			class RightDoorGun: MainTurret
			{
				animationsourcebody = "Turret_2";
				animationsourcegun = "Gun_2";
				animationsourcehatch = "";
				body = "Turret_2";
				commanding = -2;
				gun = "Gun_2";
				gunbeg = "muzzle_2";
				gunend = "chamber_2";
				gunnercompartments = "Compartment2";
				gunnername = "door gunner";
				initturn = -90;
				maxturn = -30;
				memorypointgun = "machinegun_2";
				memorypointgunneroptics = "gunnerview_2";
				minturn = -150;
				primarygunner = 0;
				proxyindex = 2;
				selectionfireanim = "zasleh_1";
				stabilizedinaxes = "StabilizedInAxesNone";
				weapons[] = {"M240_veh_2"};
			};
		};
		class Reflectors
		{
			class Left
			{
				ambient[] = {0.07, 0.07, 0.07, 1};
				brightness = 1;
				color[] = {0.8, 0.8, 1, 1};
				direction = "konec L svetla";
				hitpoint = "L svetlo";
				position = "L svetlo";
				selection = "L svetlo";
				size = 1;
			};
			class Right
			{
				ambient[] = {0.07, 0.07, 0.07, 1};
				brightness = 1;
				color[] = {0.8, 0.8, 1, 1};
				direction = "konec P svetla";
				hitpoint = "P svetlo";
				position = "P svetlo";
				selection = "P svetlo";
				size = 1;
			};
		};
	};

	class CH47_base_EP1: Helicopter {};
	class ZERO_CH47: CH47_base_EP1
	{
		radartype = 0;
		accuracy = 1000;
		crew = "ZERO_PILOT_US";
		displayname = "CH-47F";
		driveraction = "CH47_Pilot_EP1";
		icon = "\ca\air_e\data\UI\Icon_ch47f_CA.paa";
		mapsize = 24;
		maxspeed = 200;
		model = "\ca\air_E\CH47\CH_47F";
		picture = "\ca\air_e\data\UI\Picture_ch47f_CA.paa";
		scope = 2;
		typicalcargo[] = {};
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
		class Turrets: Turrets
		{
			class MainTurret: MainTurret
			{
				animationsourcehatch = "";
				body = "mainTurret";
				commanding = -2;
				gun = "mainGun";
				gunbeg = "muzzle_1";
				gunend = "chamber_1";
				gunneraction = "CH47_Gunner_EP1";
				gunnercompartments = "Compartment2";
				gunnerinaction = "CH47_Gunner_EP1";
				gunnername = "crew chief";
				gunneropticsmodel = "\ca\weapons\optika_empty";
				gunneropticsshowcursor = 1;
				gunneroutopticsshowcursor = 1;
				initelev = -30;
				initturn = 0;
				magazines[] = {"4000Rnd_762x51_M134"};
				maxelev = 30;
				maxturn = 173;
				memorypointsgetingunner = "pos gunner";
				memorypointsgetingunnerdir = "pos gunner dir";
				minelev = -50;
				minturn = -3;
				primarygunner = 0;
				soundservo[] = {"", 0.01, 1};
				stabilizedinaxes = "StabilizedInAxesNone";
				weapons[] = {"M134"};
				class ViewOptics
				{
					initanglex = 0;
					initangley = 0;
					initfov = 0.7;
					maxanglex = 30;
					maxangley = 100;
					maxfov = 1.1;
					minanglex = -30;
					minangley = -100;
					minfov = 0.25;
				};
			};
			class RightDoorGun: MainTurret
			{
				animationsourcebody = "Turret_2";
				animationsourcegun = "Gun_2";
				body = "Turret2";
				commanding = -3;
				gun = "Gun_2";
				gunbeg = "muzzle_2";
				gunend = "chamber_2";
				gunnername = "door gunner";
				initelev = -30;
				initturn = 0;
				maxelev = 30;
				maxturn = 3;
				memorypointgun = "machinegun_2";
				memorypointgunneroptics = "gunnerview_2";
				minelev = -60;
				minturn = -173;
				primarygunner = 0;
				proxyindex = 2;
				selectionfireanim = "zasleh_1";
				stabilizedinaxes = "StabilizedInAxesNone";
				weapons[] = {"M134_2"};
			};
			class BackDoorGun: MainTurret
			{
				animationsourcebody = "Turret_3";
				animationsourcegun = "Gun_3";
				body = "Turret3";
				commanding = -1;
				gun = "Gun_3";
				gunbeg = "muzzle_3";
				gunend = "chamber_3";
				gunneraction = "CH47_Gunner01_EP1";
				gunnerinaction = "CH47_Gunner01_EP1";
				gunnername = "rear gunner";
				gunneropticsshowcursor = 0;
				initelev = 0;
				initturn = 180;
				magazines[] = {"100Rnd_762x51_M240","100Rnd_762x51_M240","100Rnd_762x51_M240","100Rnd_762x51_M240","100Rnd_762x51_M240"};
				maxelev = 50;
				maxturn = 230;
				memorypointgun = "machinegun_3";
				memorypointgunneroptics = "gunnerview_3";
				minelev = -50;
				minturn = 130;
				primarygunner = 1;
				proxyindex = 3;
				selectionfireanim = "zasleh_3";
				stabilizedinaxes = "StabilizedInAxesNone";
				weapons[] = {"M240_veh"};
			};
		};
		class AnimationSources: AnimationSources
		{
			class ReloadAnim
			{
				source = "reload";
				weapon = "M240_veh";
			};
			class ReloadMagazine
			{
				source = "reloadmagazine";
				weapon = "M240_veh";
			};
			class Revolving
			{
				source = "revolving";
				weapon = "M240_veh";
			};
			class Gatling_1
			{
				source = "revolving";
				weapon = "M134";
			};
			class Gatling_2
			{
				source = "revolving";
				weapon = "M134_2";
			};
		};
	};

	class ZERO_Merlin_HC3_D: Helicopter
	{
		radartype = 0;
		accuracy = 1.5;
		armor = 60;
		backrotorspeed = 1;
		cargoaction[] = {"Merlin_Cargo_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo_BAF", "Merlin_Cargo01_BAF", "Merlin_Cargo_BAF", "Merlin_Cargo01_BAF"};
		cargoiscodriver[] = {1, 0};
		cost = "1e+007";
		crew = "ZERO_PILOT_US";
		crewvulnerable = 1;
		damageresistance = 0.00555;
		destrtype = "DestructWreck";
		displayname = "Merlin HC3";
		driveraction = "Merlin_Pilot_BAF";
		enablemanualfire = 0;
		expansion = 2;
		faction = "BIS_BAF";
		geardowntime = 1;
		gearretracting = 1;
		gearuptime = 1;
		getinaction = "GetInHigh";
		getoutaction = "GetOutHigh";
		icon = "\Ca\air_d_baf\Data\UI\icon_merlin_ca.paa";
		incommingmissliedetectionsystem = 16;
		irscanrangemax = 1000;
		irscanrangemin = 0;
		laserscanner = 1;
		lockdetectionsystem = "1.11821e+006";
		mainrotorspeed = 1;
		mapsize = 20;
		maxspeed = 250;
		memorypointsgetincargo[] = {"pos codriver", "pos cargo"};
		memorypointsgetincargodir[] = {"pos codriver dir", "pos cargo dir"};
		model = "\Ca\air_d_baf\MerlinHC3_BAF";
		nightvision = 1;
		picture = "\Ca\air_d_baf\Data\UI\picture_merlin_ca.paa";
		scope = 2;
		selectionfireanim = "zasleh";
		side = 1;
		sounddammage[] = {"Ca\sounds_baf\air\int-alarm_loop", 0.562341, 1};
		soundengineoffext[] = {"Ca\sounds_baf\air\uk_stop_ext_2", 0.562341, 1.1, 800};
		soundengineoffint[] = {"\Ca\sounds_baf\air\uk_stop_int_1", 0.1, 1.1};
		soundengineonext[] = {"Ca\sounds_baf\air\uk_start_ext_1", 0.562341, 1.1, 800};
		soundengineonint[] = {"Ca\sounds_baf\air\uk_start_int_1", 0.1, 1.1};
		soundgetin[] = {"Ca\sounds_baf\air\getin", 0.316228, 1};
		soundgetout[] = {"Ca\sounds_baf\air\getin", 0.316228, 1, 40};
		soundincommingmissile[] = {"Ca\sounds_baf\air\int-alarm_loop", 0.000316228, 4};
		soundlocked[] = {"Ca\sounds_baf\air\int-alarm_loop", 0.000316228, 2};
		supplyradius = 5;
		threat[] = {0.3, 0.3, 0.3};
		transportmaxbackpacks = 10;
		transportmaxmagazines = "90*2";
		transportmaxweapons = "18*1";
		transportsoldier = 17;
		typicalcargo[] = {};
		vehicleclass = "Air";
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
		class Library
		{
			libtextdesc = "The Merlin HC3 is a British designation for a AW101 medium-lift transport helicopter. <br />The Merlin HC3 has a maximal speed of 309 km/h and the operational range of 1380 km.";
		};
		class Reflectors
		{
			class Light
			{
				ambient[] = {0.07, 0.07, 0.07, 1};
				brightness = 1;
				color[] = {0.8, 0.8, 1, 1};
				direction = "light_1_1_dir";
				hitpoint = "light_1_1_pos";
				position = "light_1_1_pos";
				selection = "L svetlo";
				size = 1;
			};
		};
		class MarkerLights
		{
			class GreenStill
			{
				ambient[] = {0.01, 0.1, 0.01, 1};
				blinking = 0;
				brightness = 0.001;
				color[] = {0.006, 0.12, 0.006, 1};
				name = "light_nav_right";
			};
			class WhiteBlinking
			{
				ambient[] = {0.03, 0.023, 0.0056, 1};
				blinking = 1;
				brightness = 0.001;
				color[] = {0.0388, 0.0388, 0.0388, 1};
				name = "light_nav_top";
			};
			class RedStill
			{
				ambient[] = {0.1, 0.01, 0.01, 1};
				blinking = 0;
				brightness = 0.001;
				color[] = {0.12, 0.006, 0.006, 1};
				name = "light_nav_left";
			};
		};
		class AnimationSources: AnimationSources
		{
			class Doors
			{
				animperiod = 1;
				initphase = 0;
				source = "user";
			};
		};
		class UserActions
		{
			class OpenRdoor
			{
				condition = "this animationPhase 'dvere_p' > 0.5 AND Alive(this)";
				displayname = "Open door";
				onlyforplayer = 0;
				position = "axis_door_side_pop";
				radius = 3.6;
				statement = "this animate ['dvere_p',0];this animate ['dvere_p_pop',0];";
			};
			class CloseRdoor
			{
				condition = "this animationPhase 'dvere_p' < 0.5 AND Alive(this)";
				displayname = "Close door";
				onlyforplayer = 0;
				position = "axis_door_side_pop";
				radius = 3.6;
				statement = "this animate ['dvere_p',1];this animate ['dvere_p_pop',1];";
			};
			class OpenLdoor
			{
				condition = "this animationPhase 'dvere_l' > 0.5 AND Alive(this)";
				displayname = "Open door";
				onlyforplayer = 0;
				position = "axis_door_crew_pop";
				radius = 3.6;
				statement = "this animate ['dvere_l',0];this animate ['dvere_l_pop',0];";
			};
			class CloseLdoor
			{
				condition = "this animationPhase 'dvere_l' < 0.5 AND Alive(this)";
				displayname = "Close door";
				onlyforplayer = 0;
				position = "axis_door_crew_pop";
				radius = 3.6;
				statement = "this animate ['dvere_l',1];this animate ['dvere_l_pop',1];";
			};
		};
		class Turrets: Turrets {};
		class HitPoints: HitPoints
		{
			class HitHull
			{
				armor = 1;
				material = 51;
				name = "NEtrup";
				passthrough = 0.5;
				visual = "trup";
			};
			class HitEngine
			{
				armor = 0.5;
				material = 51;
				name = "motor";
				passthrough = 0.5;
				visual = "motor";
			};
			class HitAvionics
			{
				armor = 0.15;
				material = 51;
				name = "elektronika";
				passthrough = 0.2;
				visual = "elektronika";
			};
			class HitVRotor
			{
				armor = 0.3;
				material = 51;
				name = "mala vrtule";
				passthrough = 0.1;
				visual = "mala vrtule staticka";
			};
			class HitHRotor
			{
				armor = 0.2;
				material = 51;
				name = "velka vrtule";
				passthrough = 0.1;
				visual = "velka vrtule staticka";
			};
			class HitGlass1: HitGlass1
			{
				armor = 0.5;
			};
			class HitGlass2: HitGlass2
			{
				armor = 0.5;
			};
			class HitGlass3: HitGlass3
			{
				armor = 0.5;
			};
			class HitGlass4: HitGlass4
			{
				armor = 0.5;
			};
			class HitGlass5: HitGlass5
			{
				armor = 0.5;
			};
			class HitGlass6
			{
				armor = 0.5;
				material = -1;
				name = "glass6";
				passthrough = 0;
				visual = "glass6";
			};
			class HitGlass7
			{
				armor = 0.5;
				material = -1;
				name = "glass7";
				passthrough = 0;
				visual = "glass7";
			};
			class HitGlass8
			{
				armor = 0.5;
				material = -1;
				name = "glass8";
				passthrough = 0;
				visual = "glass8";
			};
			class HitGlass9
			{
				armor = 0.5;
				material = -1;
				name = "glass9";
				passthrough = 0;
				visual = "glass9";
			};
			class HitGlass10
			{
				armor = 0.5;
				material = -1;
				name = "glass10";
				passthrough = 0;
				visual = "glass10";
			};
			class HitGlass11
			{
				armor = 0.5;
				material = -1;
				name = "glass11";
				passthrough = 0;
				visual = "glass11";
			};
			class HitGlass12
			{
				armor = 0.5;
				material = -1;
				name = "glass12";
				passthrough = 0;
				visual = "glass12";
			};
			class HitGlass13
			{
				armor = 0.5;
				material = -1;
				name = "glass13";
				passthrough = 0;
				visual = "glass13";
			};
			class HitGlass14
			{
				armor = 0.5;
				material = -1;
				name = "glass14";
				passthrough = 0;
				visual = "glass14";
			};
			class HitGlass15
			{
				armor = 0.5;
				material = -1;
				name = "glass15";
				passthrough = 0;
				visual = "glass15";
			};
			class HitGlass16
			{
				armor = 0.5;
				material = -1;
				name = "glass16";
				passthrough = 0;
				visual = "glass16";
			};
			class HitGlass17
			{
				armor = 0.5;
				material = -1;
				name = "glass17";
				passthrough = 0;
				visual = "glass17";
			};
			class HitGlass18
			{
				armor = 0.5;
				material = -1;
				name = "glass18";
				passthrough = 0;
				visual = "glass18";
			};
			class HitGlass19
			{
				armor = 0.5;
				material = -1;
				name = "glass19";
				passthrough = 0;
				visual = "glass19";
			};
			class HitGlass20
			{
				armor = 0.5;
				material = -1;
				name = "glass20";
				passthrough = 0;
				visual = "glass20";
			};
		};
		class Damage
		{
			mat[] = {"ca\air_d_BAF\Data\merlin_int_01.rvmat", "ca\air_d_BAF\Data\merlin_int_01_damage.rvmat", "ca\air_d_BAF\Data\merlin_int_01_destruct.rvmat", "ca\air_d_BAF\Data\merlin_int_02.rvmat", "ca\air_d_BAF\Data\merlin_int_02_damage.rvmat", "ca\air_d_BAF\Data\merlin_int_02_destruct.rvmat", "ca\air_d_BAF\Data\Merlin_glass.rvmat", "ca\air_d_BAF\Data\Merlin_glass_damage.rvmat", "ca\air_d_BAF\Data\Merlin_glass_damage.rvmat", "ca\air_d_BAF\Data\MerlinHc3_2_BAF.rvmat", "ca\air_d_BAF\Data\MerlinHc3_2_BAF_damage.rvmat", "ca\air_d_BAF\Data\MerlinHc3_2_BAF_destruct.rvmat", "ca\air_d_BAF\Data\MerlinHc3_1_BAF.rvmat", "ca\air_d_BAF\Data\MerlinHc3_1_BAF_damage.rvmat", "ca\air_d_BAF\Data\MerlinHc3_1_BAF_destruct.rvmat"};
			tex[] = {};
		};
		class Sounds
		{
			class Engine
			{
				frequency = "rotorSpeed";
				sound[] = {"Ca\sounds_baf\air\uk_engine_ext_3", 3.16228, 1, 1000};
				volume = "camPos*((rotorSpeed-0.72)*4)";
			};
			class RotorLowOut
			{
				cone[] = {1.8, 3.14, 2, 0.9};
				frequency = "rotorSpeed";
				sound[] = {"\Ca\sounds_baf\air\uk_rotor_4l", 3.16228, 1, 1200};
				volume = "camPos*(0 max (rotorSpeed-0.1))";
			};
			class RotorHighOut
			{
				cone[] = {1.8, 3.14, 2, 0.9};
				frequency = "rotorSpeed";
				sound[] = {"\Ca\sounds_baf\air\uk_rotor_4h_swist", 1.77828, 1, 1300};
				volume = "camPos*10*(0 max (rotorThrust-0.95))";
			};
			class EngineIn
			{
				frequency = "rotorSpeed";
				sound[] = {"\Ca\sounds_baf\air\uk_engine_int_1", 0.562341, 1};
				volume = "(1-camPos)*((rotorSpeed-0.75)*4)";
			};
			class RotorLowIn
			{
				frequency = "rotorSpeed";
				sound[] = {"Ca\sounds_baf\air\uk_rotor_4l_int", 1.77828, 1};
				volume = "2*(1-camPos)*((rotorSpeed factor[0.3, 1.1]) min (rotorSpeed factor[1.1, 0.3]))";
			};
			class RotorHighIn
			{
				frequency = "rotorSpeed";
				sound[] = {"Ca\sounds_baf\air\uk_rotor_4h_int", 1.77828, 1};
				volume = "(1-camPos)*3*(rotorThrust-0.9)";
			};
		};
	};

	class UH1H_base;
	class ZERO_UH1H: UH1H_base
	{
		radartype = 0;
		maxspeed = 250;
		scope = 2;
		side = 2;
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		hiddenSelections[] = {};
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class Mi17_medevac_base;
	class ZERO_Mi8: Mi17_medevac_base
	{
		radartype = 0;
		maxspeed = 200;
		attendant = 0;
		scope = 2;
		side = 0;
		faction = "RU";
		crew = "ZERO_PILOT_RU";
		displayname = "Mi-8MT";
		hiddenselections[] = {};
		hiddenselectionstextures[] = {};
		typicalCargo[] = {};
		vehicleclass = "Air";
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class Mi24_Base
	{
		class Turrets
		{
			class MainTurret;
		};
	};
	class ZERO_Mi24: Mi24_Base
	{
		radartype = 0;
		maxspeed = 200;
		attendant = 0;
		scope = 2;
		side = 0;
		faction = "RU";
		crew = "ZERO_PILOT_RU";
		typicalCargo[] = {};
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
		class Turrets : Turrets
		{
			class MainTurret : MainTurret
			{
				body = "mainTurret";
				gun = "mainGun";
				gunbeg = "muzzle_1";
				gunend = "chamber_1";
				gunneraction = "HIND_Gunner";
				gunnergetinaction = "GetInHigh";
				gunnergetoutaction = "GetOutHigh";
				gunnerinaction = "HIND_Gunner";
				gunnername = "gunner";
				gunneropticseffect[] = {"TankGunnerOptics1"};
				gunneropticsmodel = "CA\Air_E\gunnerOptics_HIND";
				initelev = 0;
				initturn = 0;
				magazines[] = {"8000Rnd_127x108_YakB"};
				maxelev = 20;
				maxturn = 60;
				memorypointgun = "machinegun";
				minelev = -60;
				minturn = -60;
				primarygunner = 1;
				soundservo[] = {"", 0.01, 1};
				weapons[] = {"YakBNEW"};
				class ViewOptics
				{
					initanglex = 0;
					initangley = 0;
					initfov = 0.155;
					maxanglex = 30;
					maxangley = 100;
					maxfov = 0.155;
					minanglex = -30;
					minangley = -100;
					minfov = 0.047;
				};
			};
		};
	};

	class Mi17_Civilian_base_Ru;
	class ZERO_Mi17: Mi17_Civilian_base_Ru
	{
		radartype = 0;
		maxspeed = 200;
		hasgunner = 0;
		scope = 2;
		side = 2;
		displayname = "Mi-17 (Civilian)";
		hiddenselectionstextures[] = {"\CA\air\data\mi8civil_body_g_CO.paa", "\CA\air\data\mi8civil_det_g_CO.paa", "ca\air\data\clear_empty.paa", "ca\air\data\mi8_decals_ca.paa"};
		model = "\ca\air\Mi_8AMT";
		threat[] = {0, 0, 0};
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		vehicleclass = "Air";
		class TransportMagazines{};
		class TransportWeapons{};
		class Turrets{};
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class Plane
	{
		class AnimationSources;
	};
	class ZERO_MV22: Plane
	{
		radartype = 0;
		accuracy = 0.5;
		armor = 25;
		cabinopening = 0;
		cargoaction[] = {"MV22_Cargo", "Mi17_Cargo02"};
		cargocompartments[] = {"Compartment2"};
		cargoiscodriver[] = {1, 0};
		crew = "ZERO_PILOT_US";
		damageresistance = 0.00172;
		dammagefull[] = {};
		dammagehalf[] = {};
		destrtype = "DestructWreck";
		displayname = "MV-22";
		driveraction = "MV22_Pilot";
		drivercompartments = "Compartment1";
		ejectspeed[] = {0, -2, 0};
		faction = "USMC";
		gearretracting = 1;
		icon = "\ca\air2\data\UI\icon_MV22_CA.paa";
		irscanrangemax = 2000;
		irscanrangemin = 500;
		irscantoeyefactor = 2;
		mapsize = 28;
		maxspeed = 350;
		model = "\ca\air2\mv22\mv22.p3d";
		picture = "\ca\air2\data\UI\picture_MV22_CA.paa";
		scope = 2;
		side = 1;
		selectionrotormove = "engine_blur";
		selectionrotorstill = "engine_static";
		sounddammage[] = {"ca\sounds\Air\MV22\int-alarm_loop", 0.562341, 1};
		soundengineoffext[] = {"ca\sounds\Air\MV22\ext_stop", 0.562341, 1, 800};
		soundengineoffint[] = {"ca\sounds\Air\MV22\int_stop", 0.562341, 1};
		soundengineonext[] = {"ca\sounds\Air\MV22\ext_start", 0.562341, 1, 800};
		soundengineonint[] = {"ca\sounds\Air\MV22\int_start", 0.562341, 1};
		soundgetin[] = {"ca\sounds\Air\MV22\close", 0.316228, 1};
		soundgetout[] = {"ca\sounds\Air\MV22\open", 0.316228, 1, 40};
		supplyradius = 8;
		transportsoldier = 24;
		vehicleclass = "Air";
		vtol = 3;
		weapons[] = {};
		magazines[] = {};
		typicalCargo[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
		class Sounds
		{
			class EngineLowOut
			{
				frequency = "1.0 min (rpm + 0.5)";
				sound[] = {"ca\sounds\Air\MV22\ext_engine_low", 1.77828, 1, 1000};
				volume = "camPos*engineOn*(rpm factor[0.85, 0])";
			};
			class EngineHighOut
			{
				frequency = 1;
				sound[] = {"ca\sounds\Air\MV22\ext_engine_hi", 1.77828, 1, 1200};
				volume = "camPos*engineOn*(rpm factor[0.55, 1.0])";
			};
			class ForsageOut
			{
				frequency = 1;
				sound[] = {"ca\sounds\Air\MV22\ext_forsage", 1.77828, 1, 1800};
				volume = "camPos*engineOn*(thrust factor[0.5, 1.0])";
			};
			class WindNoiseOut
			{
				frequency = "(0.1+(1.2*(speed factor[1, 100])))";
				sound[] = {"ca\sounds\Air\MV22\int-wind1", 0.0177828, 0.6, 100};
				volume = "camPos*(speed factor[1, 100])";
			};
			class EngineLowIn
			{
				frequency = "1.0 min (rpm + 0.5)";
				sound[] = {"ca\sounds\Air\MV22\int_engine_low", 1, 1};
				volume = "(1-camPos)*(engineOn*(rpm factor[0.85, 0]))";
			};
			class EngineHighIn
			{
				frequency = 1;
				sound[] = {"ca\sounds\Air\MV22\int_engine_hi", 1, 1};
				volume = "(1-camPos)*(engineOn*(rpm factor[0.55, 1.0]))";
			};
			class ForsageIn
			{
				frequency = 1;
				sound[] = {"ca\sounds\Air\MV22\int_forsage", 1.41254, 1.1};
				volume = "(1-camPos)*(engineOn*(thrust factor[0.5, 1.0]))";
			};
			class WindNoiseIn
			{
				frequency = "(0.1+(1.2*(speed factor[1, 100])))";
				sound[] = {"ca\sounds\Air\MV22\int-wind1", 0.00177828, 0.6};
				volume = "(1-camPos)*(speed factor[1, 100])";
			};
		};
		class Damage
		{
			mat[] = {"ca\air2\mv22\data\mv22_sklo.rvmat", "ca\air2\mv22\data\mv22_sklo_damage.rvmat", "ca\air2\mv22\data\mv22_sklo_damage.rvmat", "ca\air2\mv22\data\mv22_sklo_in.rvmat", "ca\air2\mv22\data\mv22_sklo_in_damage.rvmat", "ca\air2\mv22\data\mv22_sklo_in_damage.rvmat", "ca\air2\mv22\data\mv22_01.rvmat", "ca\air2\mv22\data\mv22_01_damage.rvmat", "ca\air2\mv22\data\mv22_01_destruct.rvmat", "ca\air2\mv22\data\mv22_02.rvmat", "ca\air2\mv22\data\mv22_02_damage.rvmat", "ca\air2\mv22\data\mv22_02_destruct.rvmat"};
			tex[] = {};
		};
		class AnimationSources
		{
			class Door_1_1
			{
				animperiod = 0;
				source = "user";
			};
			class Ramp
			{
				animperiod = 0;
				source = "user";
			};
			class pack_engine_1
			{
				animperiod = 0;
				source = "user";
			};
			class engine_prop_1_1_turn: pack_engine_1 {};
			class engine_prop_1_2_turn: pack_engine_1 {};
			class engine_prop_1_3_turn: pack_engine_1 {};
			class engine_prop_2_1_turn: pack_engine_1 {};
			class engine_prop_2_2_turn: pack_engine_1 {};
			class engine_prop_2_3_turn: pack_engine_1 {};
			class engine_prop_1_1_close: pack_engine_1 {};
			class engine_prop_1_3_close: pack_engine_1 {};
			class engine_prop_2_1_close: pack_engine_1 {};
			class engine_prop_2_2_close: pack_engine_1 {};
			class pack_engine_2: pack_engine_1 {};
			class turn_wing: pack_engine_1 {};
		};
		class UserActions {};
		class Reflectors
		{
			class Left
			{
				ambient[] = {0.07, 0.07, 0.07, 1};
				brightness = 1;
				color[] = {0.8, 0.8, 1, 1};
				direction = "konec L svetla";
				hitpoint = "L svetlo";
				position = "L svetlo";
				selection = "L svetlo";
				size = 1;
			};
			class Right
			{
				ambient[] = {0.07, 0.07, 0.07, 1};
				brightness = 1;
				color[] = {0.8, 0.8, 1, 1};
				direction = "konec P svetla";
				hitpoint = "P svetlo";
				position = "P svetlo";
				selection = "P svetlo";
				size = 1;
			};
		};
		class Library
		{
			libtextdesc = "The V-22 Osprey is a multi-mission tilt-rotor military transport aircraft with vertical takeoff and landing (VTOL) and short takeoff and landing (STOL) abilities. It is designed to operate in a similar capacity to conventional helicopters but with the long range and high speed performance of a turboprop cruiser.<br/>The V-22 is able to reach speeds of 509 kph and can transport up to 32 passengers or up to 7 tons of cargo.";
		};
		class MFD
		{
			borderbottom = 0.1;
			borderleft = 0.09;
			borderright = 0.02;
			bordertop = 0.02;
			class MFD1
			{
				borderbottom = 0;
				borderleft = 0;
				borderright = 0;
				bordertop = 0;
				bottomleft = "HUD LD1";
				color[] = {0, 1, 0, 0.1};
				topleft = "HUD LH1";
				topright = "HUD PH1";
				class Pos10Vector
				{
					pos0[] = {0.5, 0.27};
					pos10[] = {"0.5+0.9", "0.27+0.7"};
					type = "vector";
				};
				class Bones {};
				class Draw
				{
					alpha = 0.9;
					clipbr[] = {1, 1};
					cliptl[] = {0, 0};
					color[] = {0, 1, 0};
					condition = "on";
					class Altitude
					{
						align = "left";
						down[] = {{0.28, 0.082}, 1};
						pos[] = {{0.28, 0.042}, 1};
						right[] = {{0.32, 0.042}, 1};
						scale = 1;
						source = "altitudeASL";
						sourcescale = 1;
						type = "text";
					};
					class Altitude2
					{
						align = "left";
						down[] = {{0.45, 0.082}, 1};
						pos[] = {{0.45, 0.042}, 1};
						right[] = {{0.49, 0.042}, 1};
						scale = 1;
						source = "altitudeAGL";
						sourcescale = 1;
						type = "text";
					};
					class RPM
					{
						align = "left";
						down[] = {{0.63, 0.22}, 1};
						pos[] = {{0.63, 0.18}, 1};
						right[] = {{0.67, 0.18}, 1};
						scale = 1;
						source = "rpm";
						sourcescale = 100;
						type = "text";
					};
					class RPM2
					{
						align = "left";
						down[] = {{0.802, 0.22}, 1};
						pos[] = {{0.802, 0.18}, 1};
						right[] = {{0.842, 0.18}, 1};
						scale = 1;
						source = "rpm";
						sourcescale = 100;
						type = "text";
					};
					class Fuel
					{
						align = "left";
						down[] = {{0.63, 0.465}, 1};
						pos[] = {{0.63, 0.425}, 1};
						right[] = {{0.67, 0.425}, 1};
						scale = 1;
						source = "fuel";
						sourcescale = 100;
						type = "text";
					};
					class Fuel2
					{
						align = "left";
						down[] = {{0.802, 0.465}, 1};
						pos[] = {{0.802, 0.425}, 1};
						right[] = {{0.842, 0.425}, 1};
						scale = 1;
						source = "fuel";
						sourcescale = 100;
						type = "text";
					};
					class Speed
					{
						align = "left";
						down[] = {{0.28, 0.265}, 1};
						pos[] = {{0.28, 0.225}, 1};
						right[] = {{0.32, 0.225}, 1};
						scale = 1;
						source = "speed";
						sourcescale = 2.23694;
						type = "text";
					};
				};
			};
		};
	};

	class An2_Base_EP1;
	class ZERO_AN2_CIV: An2_Base_EP1
	{
		radartype = 0;
		displayName = "An-2 (Aeroshrot)";
		scope = 2;
		side = 2;
		threat[] = {0, 0, 0};
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		hiddenselections[] = {"Camo1", "Camo2", "Camo3"};
		hiddenselectionstextures[] = {"ca\Air_E\An2\Data\an2_1_A_CO", "ca\Air_E\An2\Data\an2_2_A_CO", "ca\Air_E\An2\Data\an2_wings_A_CO"};
		class TransportMagazines{};
		class TransportWeapons{};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class ZERO_AN2_MIL: An2_Base_EP1
	{
		radartype = 0;
		displayName = "An-2 (Military)";
		scope = 2;
		side = 2;
		threat[] = {0, 0, 0};
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		hiddenselections[] = {};
		hiddenselectionstextures[] = {"ca\Air_E\An2\Data\an2_1_CO", "ca\Air_E\An2\Data\an2_2_CO", "ca\Air_E\An2\Data\an2_wings_CO"};
		class TransportMagazines{};
		class TransportWeapons{};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class AH6_Base_EP1;
	class ZERO_MH6J: AH6_Base_EP1
	{
		cargoaction[] = {"AH6j_Cargo_EP1", "MH6_Cargo01", "MH6_Cargo02", "MH6_Cargo02", "MH6_Cargo02", "MH6_Cargo03"};
		cargoiscodriver[] = {1, 0};
		radartype = 0;
		displayname = "MH-6J";
		ejectdeadcargo = 1;
		expansion = 1;
		hiddenselections[] = {"camo1", "camo2"};
		hiddenselectionstextures[] = {"ca\air_e\ah6j\data\ah6_merge1_co.paa", "ca\air_e\ah6j\data\default_co.paa"};
		icon = "\ca\air_e\data\UI\Icon_mh6j_CA.paa";
		model = "\ca\air_e\ah6j\mh6j";
		picture = "\ca\air_e\data\UI\Picture_mh6j_CA.paa";
		scope = 2;
		side = 2;
		threat[] = {0, 0, 0};
		transportsoldier = 5;
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		class TransportMagazines{};
		class TransportWeapons{};
		class Turrets {};
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class ZERO_AH6X: AH6_Base_EP1
	{
		displayname = "AH-6X";
		displaynameshort = "AH6X";
		audible = 6;
		enablemanualfire = 0;
		scope = 2;
		side = 2;
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		hiddenselections[] = {"camo1"};
		hiddenselectionstextures[] = {"ca\air_e\ah6j\data\ah6_merge1_co.paa"};
		icon = "\ca\air_e\data\UI\Icon_ah6x_CA.paa";
		model = "\ca\air_e\ah6j\ah6x";
		picture = "\ca\air_e\data\UI\Picture_ah6x_CA.paa";
		isuav = 0;
		radartype = 0;
		class TransportMagazines{};
		class TransportWeapons{};
		class Turrets {};
		weapons[] = {};
		magazines[] = {};
		gunnerHasFlares = 0;
		commanderCanSee = 2+16+32;
		gunnerCanSee = 2+16+32;
		driverCanSee = 2+16+32;
	};

	class HMMWV_Base;
	class ZERO_HMMWV: HMMWV_Base
	{
		accuracy = 0.32;
		displayname = "HMMWV";
		hasgunner = 0;
		hiddenselections[] = {"Camo1"};
		hiddenselectionstextures[] = {"\ca\wheeled\hmmwv\data\hmmwv_body_co.paa"};
		icon = "\Ca\wheeled\data\map_ico\icomap_hmwv_CA.paa";
		mapsize = 5;
		model = "ca\wheeled_E\HMMWV\HMMWV";
		picture = "\Ca\wheeled\data\ico\HMMWV_CA.paa";
		scope = 2;
		side = 2;
		transportmaxbackpacks = 4;
		crew = "ZERO_CREW";
		typicalCargo[] = {};
		class Turrets {};
		class Damage {
			mat[] = {"ca\wheeled\hmmwv\data\hmmwv_details.rvmat", "Ca\wheeled\HMMWV\data\hmmwv_details_damage.rvmat", "Ca\wheeled\HMMWV\data\hmmwv_details_destruct.rvmat", "ca\wheeled\hmmwv\data\hmmwv_body.rvmat", "Ca\wheeled\HMMWV\data\hmmwv_body_damage.rvmat", "Ca\wheeled\HMMWV\data\hmmwv_body_destruct.rvmat", "ca\wheeled\hmmwv\data\hmmwv_clocks.rvmat", "ca\wheeled\hmmwv\data\hmmwv_clocks.rvmat", "ca\wheeled\data\hmmwv_clocks_destruct.rvmat", "ca\wheeled\HMMWV\data\hmmwv_glass.rvmat", "ca\wheeled\HMMWV\data\hmmwv_glass_Half_D.rvmat", "ca\wheeled\HMMWV\data\hmmwv_glass_Half_D.rvmat", "ca\wheeled\HMMWV\data\hmmwv_glass_in.rvmat", "ca\wheeled\HMMWV\data\hmmwv_glass_in_Half_D.rvmat", "ca\wheeled\HMMWV\data\hmmwv_glass_in_Half_D.rvmat"};
			tex[] = {};
		};
	};

	class BTR40_base_EP1;
	class ZERO_BTR40: BTR40_base_EP1
	{
		crew = "ZERO_CREW";
		hiddenselectionstextures[] = {"ca\wheeled_e\btr40\data\btr40ext_co.paa"};
		maxspeed = 45; // Was 90
		scope = 2;
		side = 2;
		typicalcargo[] = {};
	};

	class Ship;
	class Fishing_Boat: Ship
	{
		maxspeed = 30; // Was 15
		crew = "ZERO_CREW";
	};

	class Smallboat_1: Ship
	{
		maxspeed = 30; // Was 10
		crew = "ZERO_CREW";
	};

	class Smallboat_2;

	class Bicycle;
	class Old_bike_base_EP1: Bicycle
	{
		class Reflectors
		{
			class Right
			{
				ambient[] = {0.1, 0.1, 0.1, 1};
				brightness = 0.5;
				color[] = {0.9, 0.8, 0.8, 1};
				direction = "konec P svetla";
				hitpoint = "P svetlo";
				position = "P svetlo";
				selection = "P svetlo";
				size = 0.5;
			};
		};
	};

	class House
	{
		class DestructionEffects;
	};

	// This parent class is made to make referring to these objects easier later with allMissionObjects
	class SpawnableWreck : House {};
	class ZERO_UH1YWreck: SpawnableWreck
	{
		model = "\ca\air2\UH1Y\UH1Y_Crashed.p3d";
		icon = "\ca\air2\data\UI\icon_UH1Y_CA.paa";
		mapSize = 15;
		displayName = "Crashed UH-1Y";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_UH60Wreck: SpawnableWreck
	{
		model = "\Ca\Misc_E\Wreck_UH60_EP1.p3d";
		icon = "ca\Misc_E\data\Icons\Icon_uh60_wreck_CA.paa";
		mapSize = 15;
		displayName = "Crashed UH-60";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_CH47FWreck: SpawnableWreck
	{
		model = "\ca\air_e\CH47\CH_47FWreck.p3d";
		icon = "\ca\air_e\Data\UI\icon_ch47f_ca.paa";
		mapSize = 15;
		displayName = "Crashed CH-47F";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_MV22Wreck: SpawnableWreck
	{
		model = "\ca\air2\MV22\MV22Wreck.p3d";
		icon = "\ca\air2\data\ui\icon_mv22_ca.paa";
		mapSize = 15;
		displayName = "Crashed MV-22";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_HC3Wreck: SpawnableWreck
	{
		model = "\ca\air_d_baf\merlinhc3_int_baf_wreck.p3d";
		icon = "ca\air_d_baf\data\ui\icon_merlin_ca.paa";
		mapSize = 15;
		displayName = "Crashed Merlin HC3";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_Mi8Wreck: SpawnableWreck
	{
		model = "\ca\air_e\Mi17\MI8Wreck.p3d";
		icon = "\ca\air\Data\map_ico\icomap_mi17_ca.paa";
		mapSize = 15;
		displayName = "Crashed Mi-8";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_Mi24Wreck: SpawnableWreck
	{
		model = "\ca\air2\Mi35\Mi24Wreck.p3d";
		icon = "\ca\air2\data\ui\icon_mi24_ca.paa";
		mapSize = 15;
		displayName = "Crashed Mi-24";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};

	class ZERO_Bush: SpawnableWreck
	{
		model = "\ca\plants2\bush\b_betulaHumilis";
		displayName = "Bush";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_Clutter: SpawnableWreck
	{
		model = "\ca\plants2\clutter\c_fernTall";
		displayName = "Clutter";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_Misc: SpawnableWreck
	{
		model = "\ca\plants2\misc\misc_FallenTree1";
		displayName = "Misc";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_Plant: SpawnableWreck
	{
		model = "\ca\plants2\plant\p_Phragmites";
		displayName = "Plant";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};
	class ZERO_Tree: SpawnableWreck
	{
		model = "\ca\plants2\tree\t_pinusN2s";
		displayName = "Tree";
		vehicleClass = "Wrecks";
		class AnimationSources {};
	};

	class Strategic;
	class NonStrategic;
	class Land_A_FuelStation_Feed: Strategic
	{
		model = "\ca\structures\House\A_FuelStation\A_FuelStation_Feed";
		transportFuel = 0; //50000;
		nameSound = "fuelstation";
	};
	class Land_Stoplight01: House
	{
		scope = 1;
		model = "\ca\buildings\Misc\stoplight01";
		armor = 50;
		class MarkerLights
		{
			class YellowTopBlinking
			{
				name = "";
				color[] = {0,0,0,0};
				ambient[] = {0,0,0,0};
				brightness = 0;
				blinking = 0;
			};
			class YellowLowBlinking
			{
				name = "";
				color[] = {0,0,0,0};
				ambient[] = {0,0,0,0};
				brightness = 0;
				blinking = 0;
			};
		};
	};
	class Land_Stoplight02: Land_Stoplight01
	{
		model = "\ca\buildings\Misc\stoplight02";
		class MarkerLights
		{
			class YellowTopBlinking
			{
				name = "";
				color[] = {0,0,0,0};
				ambient[] = {0,0,0,0};
				brightness = 0;
				blinking = 0;
			};
		};
	};
	class Land_NavigLight: House
	{
		scope = 1;
		displayName = "";
		model = "\ca\buildings\Misc\NavigLight";
		armor = 50;
		class MarkerLights
		{
			class WhiteStill
			{
				name = "";
				color[] = {0,0,0,0};
				ambient[] = {0,0,0,0};
				brightness = 0;
				blinking = 0;
			};
		};
	};
	class Land_runway_edgelight: House
	{
		scope = 1;
		displayName = "";
		model = "\ca\buildings\Misc\runway_edgelight";
		armor = 20;
		class MarkerLights
		{
			class RedStill
			{
				name = "";
				color[] = {0,0,0,0};
				ambient[] = {0,0,0,0};
				brightness = 0;
				blinking = 0;
			};
		};
	};
	class Land_VASICore: NonStrategic
	{
		scope = 1;
		animated = 0;
		reversed = 0;
		vehicleClass = "Objects";
		icon = "";
		model = "";
		displayName = "VASI";
		accuracy = 0.2;
		typicalCargo[] = {};
		destrType = "DestructBuilding";
		irTarget = 0;
		transportAmmo = 0;
		transportRepair = 0;
		transportFuel = 0;
		cost = 0;
		armor = 100;
		mapSize = 6.4;
		simulation = "house";
	};
};