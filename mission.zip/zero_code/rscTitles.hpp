class RscPicture;
class RscButton;
class CA_Title;
class CA_IGUI_Title;
class RscText;
class RscHTML;
class RscControlsGroup;
class RscLineBreak;
class RscShortcutButtonMain;
class IGUIBack;
class RscIGUIListBox;
class RscIGUIListNBox;
class RscActiveText;
class RscPictureKeepAspect;
class RscStandardDisplay;
class RscProgress;
class RscProgressNotFreeze;
class RscButtonTextOnly;

class RscShortcutButton
{
	idc = -1;
	style = 0;
	default = 0;
	shadow = 2;
	w = 0.183825;
	h = 0.104575;
	color[] = {0.8784, 0.8471, 0.651, 1.0};
	//color[] = {0.8, 0.8, 0.8, 1.0};
	color2[] = {0.95, 0.95, 0.95, 1};
	colorBackground[] = {1, 1, 1, 1};
	colorbackground2[] = {1, 1, 1, 0.4};
	colorDisabled[] = {1, 1, 1, 0.25};
	periodFocus = 1.2;
	periodOver = 0.8;

	class HitZone
	{
		left = 0.004;
		top = 0.029;
		right = 0.004;
		bottom = 0.029;
	};

	class ShortcutPos
	{
		left = 0.0145;
		top = 0.026;
		w = 0.0392157;
		h = 0.0522876;
	};

	class TextPos
	{
		left = 0.05;
		top = 0.034;
		right = 0.005;
		bottom = 0.005;
	};
	animTextureNormal = "\ca\ui\data\ui_button_normal_ca.paa";
	animTextureDisabled = "\ca\ui\data\ui_button_disabled_ca.paa";
	animTextureOver = "\ca\ui\data\ui_button_over_ca.paa";
	animTextureFocused = "\ca\ui\data\ui_button_focus_ca.paa";
	animTexturePressed = "\ca\ui\data\ui_button_down_ca.paa";
	animTextureDefault = "\ca\ui\data\ui_button_default_ca.paa";
	period = 0.4;
	font = "Zeppelin32";
	size = 0.03921;
	sizeEx = 0.03921;
	text = "";
	soundEnter[] = {"\ca\ui\data\sound\onover", 0.09, 1};
	soundPush[] = {"\ca\ui\data\sound\new1", 0.0, 0};
	soundClick[] = {"\ca\ui\data\sound\onclick", 0.07, 1};
	soundEscape[] = {"\ca\ui\data\sound\onescape", 0.09, 1};
	action = "";

	class Attributes
	{
		font = "Zeppelin32";
		color = "#E5E5E5";
		align = "left";
		shadow = "true";
	};

	class AttributesImage
	{
		font = "Zeppelin32";
		color = "#E5E5E5";
		align = "left";
	};
};

class RscDisplayLoading
{
	class Variants
	{
		class LoadingOne
		{
			class controls
			{
				class LoadingPic: RscPictureKeepAspect
				{
					text = "z\addons\zero_code\gui\dayzero_load_ca.paa";
				};
			};
		};
	};
};

class RscDisplayStart
{
	class controls
	{
		class LoadingPic: RscPictureKeepAspect
		{
			text = "z\addons\zero_code\gui\dayzero_load_ca.paa";
		};
	};
};

class RscDisplayMain: RscStandardDisplay
{
	class controlsBackground
	{
		class Mainback;
		class CA_ARMA2: RscPicture
		{
			text = "z\addons\zero_code\gui\dayzero_logo_ca.paa";
		};
	};

	class controls
	{
		class CA_Version;
		class DAYZ_Version: CA_Version
		{
			idc = -1;
			text = "DayZero Chernarus 1.1.7";
			y = "(SafeZoneH + SafeZoneY) - (1 - 0.95)";
		};
		class CA_TitleMainMenu;
		delete CA_SinglePlayer;
		class CA_MP;
		class CA_Options;
		class CA_PlayerProfile;
		class CA_Expansions;
		class CA_Exit;
	};
};

class RscDisplayMPInterrupt: RscStandardDisplay
{
	movingEnable = 0;
	enableSimulation = 1;
	onLoad = "[""Init"", _this] execVM ""\ca\ui\scripts\pauseLoadinit.sqf""; ((_this select 0) displayCtrl 1010) ctrlEnable false; ((_this select 0) displayCtrl 104) ctrlEnable false;";
	onUnload = "[""Unload"", _this] execVM ""\ca\ui\scripts\pauseOnUnload.sqf"";";

	class controlsBackground
	{
		class Mainback: RscPicture
		{
			idc = 1104;
			x = 0.045;
			y = 0.17;
			w = 0.627451;
			h = 0.836601;
			text = "\ca\ui\data\ui_background_mp_pause_ca.paa";
		};
	};

	class controls
	{
		class MissionTitle: RscText
		{
			idc = 120;
			x = 0.05;
			y = 0.818;
			text = "";
		};

		class DifficultyTitle: RscText
		{
			idc = 121;
			x = 0.05;
			y = 0.772;
			text = "";
		};

		class Paused_Title: CA_Title
		{
			idc = 523;
			x = 0.087;
			y = 0.192;
			text = $STR_DISP_MAIN_MULTI;
		};

		class CA_B_SAVE : RscShortcutButtonMain
		{
			idc = 103;
			show = 0;
			y = -500;
			x = -500;
			text = "Save";
			default = 0;
		};

		delete CA_B_Skip;
		delete CA_B_REVERT;

		class CA_B_Options: RscShortcutButtonMain
		{
			idc = 101;
			y = 0.2537 + 0.101903 * 0;
			x = 0.051;
			text = $STR_DISP_INT_OPTIONS;
			default = 0;
		};

		class CA_B_Respawn: CA_B_Options
		{
			idc = 1010;
			onButtonClick = "if (alive player) then {player setDamage 1; player setVariable[""zeroDead"",true,true]; [player,""suicide""] spawn player_zero_death;};";
			y = 0.2537 + 0.101903 * 1;
			text = $STR_DISP_INT_RESPAWN;
			default = 0;
		};

		class CA_B_Abort: CA_B_Options
		{
			onButtonClick = "call zero_forceSave;";
			idc = 104;
			y = 0.2537 + 0.101903 * 2;
			text = $STR_DISP_INT_ABORT;
			default = 0;
		};

		class ButtonCancel: RscShortcutButton
		{
			idc = 2;
			shortcuts[] = {0x00050000 + 1, 0x00050000 + 8};
			default = 1;
			x = 0.1605;
			y = 0.8617;
			text = $STR_DISP_INT_CONTINUE;
		};
	};
};

class RscDisplayDebriefing: RscStandardDisplay
{
	onLoad = "ctrlActivate ((_this select 0) displayCtrl 2)";
	class controls
	{
		delete Debriefing_MissionTitle;
		delete CA_MissionTitle;
		delete CA_TextVotingTimeLeft;
		delete CA_MissionResult;
		class CA_DebriefingInfo {};
		delete CA_DebriefingTextGroup;
		delete CA_DebriefingObjectivesGroup;
		delete CA_DebriefingStatsGroup;
		delete ButtonStatistics;
		delete ButtonRetry;
	};
	class ControlsBackground
	{
		delete Mainback;
	};
};
class RscDisplayMissionFail: RscStandardDisplay
{
	onLoad = "ctrlActivate ((_this select 0) displayCtrl 2)";
	class controls
	{
		delete Debriefing_MissionTitle;
		delete CA_MissionTitle;
		delete CA_TextVotingTimeLeft;
		delete CA_MissionResult;
		class CA_DebriefingInfo {};
		delete CA_DebriefingTextGroup;
		delete CA_DebriefingObjectivesGroup;
		delete CA_DebriefingStatsGroup;
		delete BRetry;
	};
	class ControlsBackground
	{
		delete Mainback;
	};
};

class RscDisplayDSinterface: RscStandardDisplay
{
	enableDisplay = 0;
	onLoad = "private [""_display""]; closeDialog 0; closeDialog 155; _display = findDisplay 155; _display closeDisplay 0;";
	delete controlsBackground;
	delete controls;
};

class RscDisplayHostSettings: RscStandardDisplay
{
	delete controlsBackground;
	delete controls;
};

class RscDisplayMultiplayer: RscStandardDisplay
{
	class controlsbackground
	{
		delete CA_New;
	};
};

class RscDisplayLive: RscStandardDisplay
{
	class controls
	{
		delete CreateDed;
	};
};

class RscDisplayMultiplayerSetup: RscStandardDisplay
{
	class controls
	{
		delete TextSide;
		delete TextRoles;
		delete TextPool;
		class CA_B_West: RscActiveText
		{
			x="(4.15/100)	* SafeZoneW + SafeZoneX";
			y="(21/100)	* SafeZoneH + SafeZoneY";
			w="(11.7/100)	* SafeZoneW";
			h="(7/100)	* SafeZoneH";
			style="0x02 + 0x100 + 0x40";
			type=11;
			colorActive[]={1,1,1,1};
			colorDisabled[]={1,1,1,0.15};
			colorShade[]={1,1,1,1};
			colorText[]={1,1,1,1};
			pictureWidth=1;
			pictureHeight=1;
			textHeight=0.38;
			sideDisabled="ca\ui\data\flag_none_ca.paa";
			sideToggle="ca\ui\data\flag_side_toggle_ca.paa";
			idc=104;
			color[]={1,1,1,0.55};
			text="Survivor";
			picture="\ca\ui\data\flag_civil_ca.paa";
		};
		delete CA_B_East;
		delete CA_B_Guerrila;
		delete CA_B_Civilian;
		delete CA_B_DSinterface;
	};
};

class RscButtonActionMenu: RscButton
{
	SizeEx = 0.02674;
	colorBackground[] = {0.44,0.7,0.44,1};
	colorBackgroundActive[] = {0.24,0.5,0.24,1};
	colorBackgroundDisabled[] = {1,1,1,0};
	colorFocused[] = {0.2,0.5,0.2,1};
	colorShadow[] = {1,1,1,0};
	borderSize = 0;
	w = 0.095 * safezoneW;
	h = 0.025 * safezoneH;
};

class RscStructuredText
{
	class Attributes;
};

class RscDisplayGenderSelect
{
	idd = 6902;
	enableDisplay = 1;
	class controls
	{
		class GenderPic_Man: RscActiveText
		{
			idc = -1;
			style = 48;
			text = "z\addons\zero_code\gui\gender_menu_man.paa";
			x = safezoneX + (safezoneW * (1/3)) - ((256 * ((safezoneH / 2) / 512)) / 2);
			y = safezoneY + (safezoneH / 2) - ((safezoneH / 2) / 2);
			w = 256 * ((safezoneH / 2) / 512);
			h = safezoneH / 2;
			color[] = { 0.5, 0.5, 0.5, 1 };
			colorActive[] = { 1, 1, 1, 1 };
			action = "closeDialog 0;dayz_selectGender = 'Survivor2_DZ';";
		};
		class GenderPic_Woman: RscActiveText
		{
			idc = -1;
			style = 48;
			text = "z\addons\zero_code\gui\gender_menu_woman.paa";
			x = safezoneX + (safezoneW * (2/3)) - ((256 * ((safezoneH / 2) / 512)) / 2);
			y = safezoneY + (safezoneH / 2) - ((safezoneH / 2) / 2);
			w = 256 * ((safezoneH / 2) / 512);
			h = safezoneH / 2;
			color[] = { 0.5, 0.5, 0.5, 1 };
			colorActive[] = { 1, 1, 1, 1 };
			action = "closeDialog 0;dayz_selectGender = 'SurvivorW2_DZ';";
		};
		class Gender_Title: RscStructuredText
		{
			idc = -1;
			text = "$STR_UI_GENDER_TITLE";
			x = 0.4 * safezoneW + safezoneX;
			y = 0.221864 * safezoneH + safezoneY;
			w = 0.2 * safezoneW;
			h = 0.05 * safezoneH;
			colorBackground[] = {-1,-1,-1,0};
		};
		class Gender_Description: RscStructuredText
		{
			idc = -1;
			text = "$STR_UI_GENDER_DESC";
			x = 0.4 * safezoneW + safezoneX;
			y = 0.366134 * safezoneH + safezoneY;
			w = 0.2 * safezoneW;
			h = 0.3 * safezoneH;
			colorBackground[] = {-1,-1,-1,0};
		};
	};
};

class RscGearShortcutButton: RscShortcutButton
{
	w = 0.0392157;
	h = 0.0522876;
	style = 2;
	color[] = {1, 1, 1, 1};
	color2[] = {1, 1, 1, 0.85};
	colorBackground[] = {1, 1, 1, 1};
	colorbackground2[] = {1, 1, 1, 0.85};
	colorDisabled[] = {1, 1, 1, 0.4};

	class HitZone
	{
		left = 0.0;
		top = 0.0;
		right = 0.0;
		bottom = 0.0;
	};

	class ShortcutPos
	{
		left = -0.006;
		top = -0.007;
		w = 0.0392157;
		h = 0.0522876;
	};

	class TextPos
	{
		left = 0.003;
		top = 0.001;
		right = 0.0;
		bottom = 0.0;
	};
	sizeEx = 0.1;
	animTextureNormal = "\ca\ui\data\igui_gear_normal_ca.paa";
	animTextureDisabled = "\ca\ui\data\igui_gear_disabled_ca.paa";
	animTextureOver = "\z\addons\zero_code\gui\igui_gear_over_ca.paa";
	animTextureFocused = "\z\addons\zero_code\gui\igui_gear_focus_ca.paa";
	animTexturePressed = "\z\addons\zero_code\gui\igui_gear_down_ca.paa";
	animTextureDefault = "\ca\ui\data\igui_gear_normal_ca.paa";

	class Attributes
	{
		font = "Zeppelin32";
		color = "#E5E5E5";
		align = "center";
		shadow = "false";
	};
};

class RscIGUIShortcutButton: RscShortcutButton
{
	w = 0.183825;
	h = 0.0522876;
	style = 2;
	color[] = {1, 1, 1, 1};
	color2[] = {1, 1, 1, 0.85};
	colorBackground[] = {1, 1, 1, 1};
	colorbackground2[] = {1, 1, 1, 0.85};
	colorDisabled[] = {1, 1, 1, 0.4};

	class HitZone
	{
		left = 0.002;
		top = 0.003;
		right = 0.002;
		bottom = 0.016;
	};

	class ShortcutPos
	{
		left = -0.006;
		top = -0.007;
		w = 0;
		h = 0.0522876;
	};

	class TextPos
	{
		left = 0.0;
		top = 0.0;
		right = 0.0;
		bottom = 0.016;
	};
	animTextureNormal = "\z\addons\zero_code\gui\igui_button_normal_ca.paa";
	animTextureDisabled = "\z\addons\zero_code\gui\igui_button_disabled_ca.paa";
	animTextureOver = "\z\addons\zero_code\gui\igui_button_over_ca.paa";
	animTextureFocused = "\z\addons\zero_code\gui\igui_button_focus_ca.paa";
	animTexturePressed = "\z\addons\zero_code\gui\igui_button_down_ca.paa";
	animTextureDefault = "\z\addons\zero_code\gui\igui_button_normal_ca.paa";

	class Attributes
	{
		font = "Zeppelin32";
		color = "#E5E5E5";
		align = "center";
		shadow = "true";
	};
};

class RscDisplayMainMap
{
	class controls
	{
		delete CA_MainBackground;
		delete CA_TopicsBackground;
		class CA_SubTopicsBackground: IGUIBack
		{
			idc=1022;
			x="0.16*SafeZoneW + SafeZoneX";
			y="SafeZoneY + 0.117";
			w="0.283*SafeZoneW";
			h=0.53;
			colorBackground[] = {0.30,0.30,0.30,0.85};
		};

		class CA_ContentBackground: IGUIBack
		{
			idc = 1023;
			x = "0.446*SafeZoneW + SafeZoneX";
			y = "SafeZoneY + 0.117";
			w = "SafeZoneW * 0.272";
			h = 0.832;
			colorBackground[] = {0.30,0.30,0.30,0.85};
		};
		delete CA_PlayerName;
		delete CA_PlayerRank;
		delete CA_MissionName;
		delete CA_CurrentTaskLabel;
		delete CA_CurrentTask;
		class DiaryList: RscIGUIListBox
		{
			idc = 1001;
			colorText[] = {0.30,0.30,0.30,1};
			colorSelectBackground[]={0.60,0.60,0.60,1};
			colorSelectBackground2[]={0.60,0.60,0.60,1};
			onLBSelChanged = " [ _this select 0 , _this select 1 , 'List' ] call compile preprocessFileLineNumbers 'ca\Warfare2\Scripts\Client\GUI\GUI_logEH.sqf'; ";
			default = 1;
			x = "-10";
			y = "-10";
			w = "0.146*SafeZoneW";
			h = 0.6;
		};
		class CA_DiaryIndex: RscIGUIListBox
		{
			colorText[] = {0.30,0.30,0.30,1};
			colorSelectBackground[] = {0.60,0.60,0.60,1};
			colorSelectBackground2[] = {0.60,0.60,0.60,1};
		};
		class CA_DiaryGroup: RscControlsGroup
		{
			colorText[] = {0.60,0.60,0.60,1};
			class Controls
			{
				class CA_Diary: RscHTML
				{
					colorText[] = {0.95,0.95,0.95,1};
				};
			};
		};
	};
};

class RscDisplayGear
{
	idd = 106;
	enableDisplay = 1;
	onUnload = "call player_gearSync;";
	class controls
	{
		class CA_Filter_Icon: RscPicture
		{
			idc = 148;
			style = "0x30 + 0x800";
			x = 0.04;
			y = 0.544098;
			w = 0.458;
			h = 0.075;
			text = "\z\addons\zero_code\gui\igui_gear_filter_1_ca.paa";
		};
		class CA_Filter_Left_Icon: RscPicture
		{
			idc = 1301;
			style = "0x30 + 0x800";
			x = 0.05;
			y = 0.545098;
			w = 0.036;
			h = 0.075;
			text = "\ca\ui\data\arrow_left_ca.paa";
		};
		class CA_Filter_Right_Icon: RscPicture
		{
			idc = 1302;
			style = "0x30 + 0x800";
			x = 0.453;
			y = 0.545098;
			w = 0.036;
			h = 0.075;
			text = "\ca\ui\data\arrow_right_ca.paa";
		};
		class CA_Filter_Arrow_Left: RscButton
		{
			idc = 150;
			colorText[] = {1,1,1,0};
			colorDisabled[] = {1,1,1,0};
			colorBackground[] = {1,1,1,0};
			colorBackgroundDisabled[] = {1,1,1,0};
			colorBackgroundActive[] = {1,1,1,0};
			colorShadow[] = {1,1,1,0};
			colorFocused[] = {1,1,1,0};
			x = 0.041;
			y = 0.545098;
			w = 0.056;
			h = 0.075;
			text = "";
		};
		class CA_Filter_Arrow_Right: RscButton
		{
			idc = 151;
			colorText[] = {1,1,1,0};
			colorDisabled[] = {1,1,1,0};
			colorBackground[] = {1,1,1,0};
			colorBackgroundDisabled[] = {1,1,1,0};
			colorBackgroundActive[] = {1,1,1,0};
			colorShadow[] = {1,1,1,0};
			colorFocused[] = {1,1,1,0};
			x = 0.443;
			y = 0.545098;
			w = 0.056;
			h = 0.075;
			text = "";
		};
		class CA_Filter_Icon1: RscButton
		{
			idc = 149;
			colorText[] = {1,1,1,0};
			colorDisabled[] = {1,1,1,0};
			colorBackground[] = {1,1,1,0};
			colorBackgroundDisabled[] = {1,1,1,0};
			colorBackgroundActive[] = {1,1,1,0};
			colorShadow[] = {1,1,1,0};
			colorFocused[] = {1,1,1,0};
			x = 0.099;
			y = 0.545098;
			w = 0.341;
			h = 0.075;
			text = "";
		};
		class Gear_Title: CA_IGUI_Title
		{
			idc = 1001;
			x = 0.047634;
			y = -0.00102941;
			text = "Gear";
		};
		class Unit_Title: RscText
		{
			idc = 101;
			colorText[] = {0,0,0,0};
			style = 2;
			x = 0.502419;
			y = 0.0492156;
			w = 0.456;
			text = "";
		};
		class Available_items_Text: RscText
		{
			idc = 156;
			x = 0.0433014;
			y = 0.0526966;
			w = 0.389709;
			h = 0.029412;
		};
		class CA_ItemName: Available_items_Text
		{
			idc = 1101;
			colorText[] = {0.60,0.60,0.60,1};
			x = 0.0416704;
			y = 0.627451;
			text = "Gear of the unit:";
		};
		class CA_Money: RscText
		{
			idc = 1102;
			style = 1;
			show = 0;
			x = -2.50409;
			y = -2.85784;
			w = 0.228;
			text = "Money:";
		};
		class CA_Money_Value: RscText
		{
			idc = 1103;
			x = -2.72794;
			y = -2.85784;
			w = 0.228;
			text = "0";
		};
		class ListboxArrows: RscControlsGroup
		{
			x = 0.04;
			y = 0.0892447;
			w = 0.48;
			h = 0.449;
			idc = 155;
			class VScrollbar
			{
				autoScrollSpeed = -1;
				autoScrollDelay = 5;
				autoScrollRewind = 0;
				color[] = {1,1,1,0};
				width = 0.001;
			};
			class HScrollbar
			{
				color[] = {1,1,1,0};
				height = 0.001;
			};
			class Controls
			{
				class CA_B_Add: RscGearShortcutButton
				{
					idc = 146;
					x = -2;
					style = 2048;
					onSetFocus = "[_this,'onFocus'] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					onButtonClick = "false call dz_fn_meleeMagazines; [_this,'onLBListSelChanged'] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					text = "&lt;";
				};
				class Available_items: RscIGUIListNBox
				{
					idc = 105;
					columns[] = {0.075,0.175,0.81,0.67};
					drawSideArrows = 1;
					idcRight = 147;
					idcLeft = 146;
					colorPlayerItem[] = {0.95,0.95,0.95,1};
					colorSelectBackground[]={0.30,0.30,0.30,1};
					colorSelectBackground2[]={0.30,0.30,0.30,1};
					class ScrollBar
					{
						color[]={1,1,1,0.6};
						colorActive[]={1,1,1,1};
						colorDisabled[]={1,1,1,0.3};
						thumb="\z\addons\zero_code\gui\igui_scrollbar_thumb_ca.paa";
						arrowFull="\z\addons\zero_code\gui\igui_arrow_top_active_ca.paa";
						arrowEmpty="\z\addons\zero_code\gui\igui_arrow_top_ca.paa";
						border="\z\addons\zero_code\gui\igui_border_scroll_ca.paa";
					};
					onLBSelChanged = "[_this,'onLBSelChanged'] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					onLBListSelChanged = "[_this,'onLBListSelChanged'] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					onKillFocus = "[_this,'onKillFocus'] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					x = 0;
					y = 0;
					w = 0.46;
					h = 0.449;
					canDrag = 1;
				};
				class CA_B_Remove: CA_B_Add
				{
					idc = 147;
					x = -2;
					onSetFocus = "[_this,""onFocus""] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					onButtonClick = "false call dz_fn_meleeMagazines; [_this,""onLBListSelChanged""] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
					text = ">";
				};
			};
		};
		class CA_CustomDescription: RscStructuredText
		{
			idc = 1106;
			x = 0.0414969;
			y = 0.663641;
			w = 0.458;
			h = 0.152;
			colorText[] = {0.95,0.95,0.95,1};
			class Attributes
			{
				font = "Zeppelin32";
				color = "#F2F2F2";
				align = "left";
				shadow = 1;
			};
		};
		class CA_Item_Picture: RscPicture
		{
			idc = 1104;
			style = "0x30 + 0x800";
			x = 0.330883;
			y = 0.785541;
			w = 0.156863;
			h = 0.104575;
			text = "";
		};
		class G_Interaction: RscControlsGroup
		{
			idc = 6902;
			x = 0.502;
			y = 0.250 * safezoneH;
			w = 0.145 * safezoneW;
			h = 0; //0.250 * safezoneH;
			onMouseMoving = "_this call gear_ui_offMenu;";
			class VScrollbar
			{
				autoScrollSpeed = -1;
				autoScrollDelay = 5;
				autoScrollRewind = 0;
				color[] = {1,1,1,0};
				width = 0.001;
			};
			class HScrollbar
			{
				color[] = {1,1,1,0};
				height = 0.001;
			};
			class Controls
			{
				class RscButton_1600: RscButtonActionMenu
				{
					idc = 1600;
					text = "";
					x = 0;
					y = 0 * safezoneH;
				};
				class RscButton_1601: RscButtonActionMenu
				{
					idc = 1601;
					text = "";
					x = 0;
					y = 0.025 * safezoneH;
				};
				class RscButton_1602: RscButtonActionMenu
				{
					idc = 1602;
					text = "";
					x = 0;
					y = 0.05 * safezoneH;
				};
				class RscButton_1603: RscButtonActionMenu
				{
					idc = 1603;
					text = "";
					x = 0;
					y = 0.075 * safezoneH;
				};
				class RscButton_1604: RscButtonActionMenu
				{
					idc = 1604;
					text = "";
					x = 0;
					y = 0.1 * safezoneH;
				};
				class RscButton_1605: RscButtonActionMenu
				{
					idc = 1605;
					text = "";
					x = 0;
					y = 0.125 * safezoneH;
				};
				class RscButton_1606: RscButtonActionMenu
				{
					idc = 1606;
					text = "";
					x = 0;
					y = 0.15 * safezoneH;
				};
				class RscButton_1607: RscButtonActionMenu
				{
					idc = 1607;
					text = "";
					x = 0;
					y = 0.175 * safezoneH;
				};
				class RscButton_1608: RscButtonActionMenu
				{
					idc = 1608;
					text = "";
					x = 0;
					y = 0.2 * safezoneH;
				};
				class RscButton_1609: RscButtonActionMenu
				{
					idc = 1609;
					text = "";
					x = 0;
					y = 0.225 * safezoneH;
				};
			};
		};
		class G_GearItems: RscControlsGroup
		{
			idc = 160;
			x = 0.502;
			y = 0.09;
			w = 0.463;
			h = 0.776;
			class VScrollbar
			{
				autoScrollSpeed = -1;
				autoScrollDelay = 5;
				autoScrollRewind = 0;
				color[] = {1,1,1,0};
				width = 0.001;
			};
			class HScrollbar
			{
				color[] = {1,1,1,0};
				height = 0.001;
			};
			class Controls
			{
				class CA_Gear_slot_primary: RscActiveText
				{
					idc = 107;
					x = "0.502 - 0.502";
					y = "0.244 - 0.09";
					w = 0.286;
					h = 0.15;
					style = "0x30 + 0x800";
					onMouseButtonDown = "_this call player_selectSlot;";
					//onMouseButtonDblClick = "if (!(ctrlShown ((findDisplay 106) displayCtrl 158)) && ((gearSlotData (_this select 0)) isKindOf 'Bag_Base_EP1')) then { call zero_compressMags; };";
					soundDoubleClick[] = {"",0.1,1};
					color[] = {1,1,1,1};
					colorBackground[] = {0.30,0.30,0.30,1};
					colorBackgroundSelected[] = {0.30,0.30,0.30,1};
					colorFocused[] = {0,0,0,0};
					canDrag = 1;
				};
				class CA_Gear_slot_secondary: CA_Gear_slot_primary
				{
					idc = 108;
					y = "0.398 -0.09";
				};
				class CA_Gear_slot_item1: CA_Gear_slot_primary
				{
					idc = 109;
					x = "0.790 - 0.502";
					y = "0.244 - 0.09";
					w = 0.055;
					h = 0.074;
				};
				class CA_Gear_slot_item2: CA_Gear_slot_item1
				{
					idc = 110;
					x = "0.847 - 0.502";
					y = "0.244 - 0.09";
				};
				class CA_Gear_slot_item3: CA_Gear_slot_item1
				{
					idc = 111;
					x = "0.904366 - 0.502";
					y = "0.244 - 0.09";
				};
				class CA_Gear_slot_item4: CA_Gear_slot_item1
				{
					idc = 112;
					x = "0.790 - 0.502";
					y = "0.321 - 0.09";
				};
				class CA_Gear_slot_item5: CA_Gear_slot_item1
				{
					idc = 113;
					x = "0.847 - 0.502";
					y = "0.321 - 0.09";
				};
				class CA_Gear_slot_item6: CA_Gear_slot_item1
				{
					idc = 114;
					x = "0.904366 - 0.502";
					y = "0.321 - 0.09";
				};
				class CA_Gear_slot_item7: CA_Gear_slot_item1
				{
					idc = 115;
					x = "0.790 - 0.502";
					y = "0.398 - 0.09";
				};
				class CA_Gear_slot_item8: CA_Gear_slot_item7
				{
					idc = 116;
					x = "0.847 - 0.502";
					y = "0.398 - 0.09";
				};
				class CA_Gear_slot_item9: CA_Gear_slot_item7
				{
					idc = 117;
					x = "0.904366 - 0.502";
					y = "0.398 - 0.09";
				};
				class CA_Gear_slot_item10: CA_Gear_slot_item7
				{
					idc = 118;
					x = "0.790 - 0.502";
					y = "0.474 - 0.09";
				};
				class CA_Gear_slot_item11: CA_Gear_slot_item7
				{
					idc = 119;
					x = "0.847 - 0.502";
					y = "0.474 - 0.09";
				};
				class CA_Gear_slot_item12: CA_Gear_slot_item7
				{
					idc = 120;
					x = "0.904366 - 0.502";
					y = "0.474 - 0.09";
				};
				class CA_Gear_slot_handgun: CA_Gear_slot_primary
				{
					idc = 121;
					x = "0.560 - 0.502";
					y = "0.551 - 0.09";
					w = 0.113;
					h = 0.15;
				};
				class CA_Gear_slot_handgun_item1: CA_Gear_slot_item1
				{
					idc = 122;
					x = "0.674 - 0.502";
					y = "0.551 - 0.09";
					w = 0.055;
					h = 0.074;
				};
				class CA_Gear_slot_handgun_item2: CA_Gear_slot_handgun_item1
				{
					idc = 123;
					x = "0.733 - 0.502";
					y = "0.551 - 0.09";
				};
				class CA_Gear_slot_handgun_item3: CA_Gear_slot_handgun_item1
				{
					idc = 124;
					x = "0.790 - 0.502";
				};
				class CA_Gear_slot_handgun_item4: CA_Gear_slot_handgun_item1
				{
					idc = 125;
					x = "0.847 - 0.502";
				};
				class CA_Gear_slot_handgun_item5: CA_Gear_slot_handgun_item1
				{
					idc = 126;
					x = "0.674 - 0.502";
					y = "0.628 - 0.09";
				};
				class CA_Gear_slot_handgun_item6: CA_Gear_slot_handgun_item5
				{
					idc = 127;
					x = "0.733 - 0.502";
					y = "0.628 - 0.09";
				};
				class CA_Gear_slot_handgun_item7: CA_Gear_slot_handgun_item5
				{
					idc = 128;
					x = "0.790 - 0.502";
					y = "0.628 - 0.09";
				};
				class CA_Gear_slot_handgun_item8: CA_Gear_slot_handgun_item5
				{
					idc = 129;
					x = "0.847 - 0.502";
					y = "0.628 - 0.09";
				};
				class CA_Gear_slot_special1: CA_Gear_slot_item1
				{
					idc = 130;
					x = "0.502 - 0.502";
					y = "0.09 - 0.09";
					w = 0.113;
					h = 0.15;
				};
				class CA_Gear_slot_special2: CA_Gear_slot_special1
				{
					idc = 131;
					x = "0.847 - 0.502";
					y = "0.09 - 0.09";
					w = 0.113;
					h = 0.15;
				};
				class CA_Gear_slot_inventory1: CA_Gear_slot_special1
				{
					idc = 134;
					x = "0.560 - 0.502";
					y = "0.705 - 0.09";
					w = 0.055;
					h = 0.074;
				};
				class CA_Gear_slot_inventory2: CA_Gear_slot_inventory1
				{
					idc = 135;
					x = "0.617 - 0.502";
					y = "0.705 - 0.09";
				};
				class CA_Gear_slot_inventory3: CA_Gear_slot_inventory1
				{
					idc = 136;
					x = "0.674 - 0.502";
					y = "0.705 - 0.09";
				};
				class CA_Gear_slot_inventory4: CA_Gear_slot_inventory1
				{
					idc = 137;
					x = "0.733 - 0.502";
					y = "0.705 - 0.09";
				};
				class CA_Gear_slot_inventory5: CA_Gear_slot_inventory1
				{
					idc = 138;
					x = "0.790 - 0.502";
					y = "0.705 - 0.09";
				};
				class CA_Gear_slot_inventory6: CA_Gear_slot_inventory1
				{
					idc = 139;
					x = "0.847 - 0.502";
					y = "0.705 - 0.09";
				};
				class CA_Gear_slot_inventory7: CA_Gear_slot_inventory1
				{
					idc = 140;
					x = "0.560 - 0.502";
					y = "0.782 - 0.09";
				};
				class CA_Gear_slot_inventory8: CA_Gear_slot_inventory7
				{
					idc = 141;
					x = "0.617 - 0.502";
					y = "0.782 - 0.09";
				};
				class CA_Gear_slot_inventory9: CA_Gear_slot_inventory7
				{
					idc = 142;
					x = "0.674 - 0.502";
					y = "0.782 - 0.09";
				};
				class CA_Gear_slot_inventory10: CA_Gear_slot_inventory7
				{
					idc = 143;
					x = "0.733 - 0.502";
					y = "0.782 - 0.09";
				};
				class CA_Gear_slot_inventory11: CA_Gear_slot_inventory7
				{
					idc = 144;
					x = "0.790 - 0.502";
					y = "0.782 - 0.09";
				};
				class CA_Gear_slot_inventory12: CA_Gear_slot_inventory7
				{
					idc = 145;
					x = "0.847 - 0.502";
					y = "0.782 - 0.09";
				};
				class CA_Gear_slot_inventory13: CA_Gear_slot_inventory7
				{
					idc = 1122;
					x = 10.1;
					y = 10.1;
				};
			};
		};
		class BagItemsGroup: RscControlsGroup
		{
			x = 0.502;
			y = 0.09;
			w = 0.463;
			h = 0.776;
			idc = 159;
			magW = 0.055;
			magH = 0.074;
			weaponW = 0.226;
			weaponH = 0.15;
			gunW = 0.113;
			gunH = 0.15;
			spacing = 0.002;
			text = "";
			color[] = {1,1,1,1};
			colorBackground[] = {1,1,1,1};
			colorBackgroundSelected[] = {1,1,1,1};
			colorFocused[] = {1,1,1,1};
			soundPush[] = {"",0.1,1};
			soundClick[] = {"",0.1,1};
			soundDoubleClick[] = {"",0.1,1};
			class VScrollbar
			{
				autoScrollSpeed = -1;
				autoScrollDelay = 5;
				autoScrollRewind = 0;
				color[] = {1,1,1,0};
				width = 0.001;
			};
			class HScrollbar
			{
				color[] = {1,1,1,0};
				height = 0.001;
			};
			class ScrollBar
			{
				color[] = {1,1,1,0.6};
				colorActive[] = {1,1,1,1};
				colorDisabled[] = {1,1,1,0.3};
				thumb = "\ca\ui\data\ui_scrollbar_thumb_ca.paa";
				arrowFull = "\ca\ui\data\ui_arrow_top_active_ca.paa";
				arrowEmpty = "\ca\ui\data\ui_arrow_top_ca.paa";
				border = "\ca\ui\data\ui_border_scroll_ca.paa";
			};
			class Controls
			{
			};
		};
		class Break_7: RscLineBreak
		{
		};
		class ButtonFilters: RscIGUIShortcutButton
		{
			idc = 148;
			shortcuts[] = {"0x00050000 + 3"};
			x = 0.333336;
			y = 0.897067;
			text = "Filter";
		};
		class ButtonRearm : RscIGUIShortcutButton
		{
			idc = 132;
			show = 0;
			x = -500;
			y = -500;
			text = "Rearm";
		};
		class ButtonOpenBag: RscIGUIShortcutButton
		{
			idc = 157;
			shortcuts[] = {"0x00050000 + 2"};
			x = 0.554743;
			y = 0.897067;
			text = "Open bag";
			//action = "call zero_compressMags;";
		};
		class ButtonCloseBag: RscIGUIShortcutButton
		{
			idc = 158;
			shortcuts[] = {"0x00050000 + 2"};
			x = 0.554743;
			y = 0.897067;
			text = "Close bag";
		};
		class ButtonContinue: RscIGUIShortcutButton
		{
			idc = 1;
			shortcuts[] = {"0x00050000 + 0",28,57,156};
			x = 0.77615;
			y = 0.897066;
			default = 1;
		};
		class ButtonClose: RscIGUIShortcutButton
		{
			idc = 2;
			shortcuts[] = {"0x00050000 + 1"};
			x = 0.0392216;
			y = 0.897066;
			text = "Close";
		};
	};
	class Filters
	{
		class All
		{
			name = "All";
			mask = -1;
			image = "\z\addons\zero_code\gui\igui_gear_filter_1_ca.paa";
		};
		class Primary
		{
			name = "Primary";
			mask = 769;
			image = "\z\addons\zero_code\gui\igui_gear_filter_2_ca.paa";
		};
		class Secondary
		{
			name = "Secondary";
			mask = 516;
			image = "\z\addons\zero_code\gui\igui_gear_filter_3_ca.paa";
		};
		class HandGun
		{
			name = "HandGun";
			mask = 18;
			image = "\z\addons\zero_code\gui\igui_gear_filter_4_ca.paa";
		};
		class Items
		{
			name = "Items";
			mask = 135168;
			image = "\z\addons\zero_code\gui\igui_gear_filter_5_ca.paa";
		};
	};
	movingEnable = 1;
	emptyGun = "\ca\ui\data\ui_gear_gun_gs.paa";
	emptySec = "\ca\ui\data\ui_gear_sec_gs.paa";
	emptyEq = "\ca\ui\data\ui_gear_eq_gs.paa";
	emptyMag = "\ca\ui\data\ui_gear_mag_gs.paa";
	emptyMag2 = "\ca\ui\data\ui_gear_mag2_gs.paa";
	emptyHGun = "\ca\ui\data\ui_gear_hgun_gs.paa";
	emptyHGunMag = "\ca\ui\data\ui_gear_hgunmag_gs.paa";
	onLoad = "false call dz_fn_meleeMagazines; dayz_gearThread = cursorTarget spawn object_monitorGear; call gear_ui_init; call ui_gear_sound; if (isNil 'IGUI_GEAR_activeFilter') then {IGUI_GEAR_activeFilter = 0}; [_this, 'onLoad'] execVM '\z\addons\dayz_code\system\handleGear.sqf'";
	class ControlsBackground
	{
		class Mainback: RscPicture
		{
			idc = 1005;
			x = 0.04;
			y = 0.01;
			w = 1.2549;
			h = 1.6732;
			moving = 1;
			text = "\z\addons\zero_code\gui\igui_background_gear_ca.paa";
		};
	};
};

class RscDisplayInspectVehicle
{
	idd = 9763;
	enableDisplay = 1;
	onLoad="uiNamespace setVariable ['redux_vehicleInspect', _this select 0]";
	class controls
	{
		class RscText_1000: RscText
		{
			idc = 1000;
			x = 0.334375 * safezoneW + safezoneX;
			y = 0.310417 * safezoneH + safezoneY;
			w = 0.343984 * safezoneW;
			h = 0.351528 * safezoneH;
			colorBackground[] = {0,0,0,0.9};
		};
		class RscText_1001: RscText
		{
			style = ST_CENTER;

			idc = 1001;
			text = "Vehicle Inspection";
			x = 0.334375 * safezoneW + safezoneX;
			y = 0.281944 * safezoneH + safezoneY;
			w = 0.343984 * safezoneW;
			h = 0.0286111 * safezoneH;
			colorBackground[] = {0,0.2,0,0.9};
		};
		class RscShortcutButton_1700: RscShortcutButton
		{
			idc = 1700;
			text = "Close";
			x = 0.472264 * safezoneW + safezoneX;
			y = 0.614583 * safezoneH + safezoneY;
			w = 0.063125 * safezoneW;
			h = 0.0591667 * safezoneH;
			colorBackground[] = {0,0.4,0,1};
			colorBackgroundActive[] = {0,0,0,1};
			onButtonClick = "closeDialog 0;";
		};
		class RscText_1002: RscText
		{
			style = ST_MULTI;
			lineSpacing = 1;
			idc = 1002;
			sizeEx = 0.0275;
			text = "Loading...";
			x = 0.348046 * safezoneW + safezoneX;
			y = 0.334306 * safezoneH + safezoneY;
			w = 0.317812 * safezoneW;
			h = 0.282778 * safezoneH;
		};
		class RscText_1003: RscPictureKeepAspect
		{
			idc = 1003;
			sizeEx = 0.0275;
			text = "";
			x = 0.438046 * safezoneW + safezoneX;
			y = 0.334306 * safezoneH + safezoneY;
			w = 0.227812 * safezoneW;
			h = 0.282778 * safezoneH;
		};
		class RscText_1004: RscPictureKeepAspect
		{
			idc = 1004;
			sizeEx = 0.0275;
			text = "";
			x = 0.438046 * safezoneW + safezoneX;
			y = 0.334306 * safezoneH + safezoneY;
			w = 0.227812 * safezoneW;
			h = 0.282778 * safezoneH;
		};
		class RscText_1005: RscText
		{
			style = ST_CENTER;

			idc = 1005;
			sizeEx = 0.0275;
			text = "";
			x = 0.438046 * safezoneW + safezoneX;
			y = 0.580000 * safezoneH + safezoneY;
			w = 0.227812 * safezoneW;
			h = 0.0591667 * safezoneH;
		};
	};
};

class RscPictureGUI
{
	access = 0;
	type = 0;
	idc = -1;
	colorBackground[] = {0,0,0,0};
	//colorText[] = {0.38,0.63,0.26,0.75};
	colorText[] = {1,1,1,0.75};
	font = "TahomaB";
	sizeEx = 0;
	lineSpacing = 0;
	text = "";
	style = "0x30 + 0x100";
	shadow = 2;
	x = 0;
	y = 0;
	w = 0.2;
	h = 0.15;
};

class RscTextGUI
{
	type = 13;
	idc = -1;
	style = ST_RIGHT;
	colorBackground[] = {0,0,0,0};
	colorText[] = {1,1,1,0.75};
	font = "Zeppelin32";
	shadow = 2;
	sizeEx = 0.04;
	size = 0.04;
	h = 0.25;
	text = "";
	class Attributes
	{
		align = "right";
	};
};

class RscStructuredTextGUI: RscStructuredText
{
	colorBackground[] = {0,0,0,0};
	colorText[] = {1,1,1,1};
	class Attributes: Attributes
	{
		align = "center";
		valign = "middle";
	};
};

class RscTitles
{
	class Default
	{
		idd = -1;
		movingEnable = 0;
		duration = 4;
	};
	class playerKillScore
	{
		idd = 6902;
		movingEnable = 0;
		duration = 5;
		name = "playerKillScore";
		onLoad = "uiNamespace setVariable ['DAYZ_GUI_kills', _this select 0];";
		class ControlsBackground
		{
			class RscPicture_1201: RscPictureGUI
			{
				idc = 1400;
				text = "\z\addons\zero_code\gui\stats_kills_human_ca.paa";
				x = 0.044687 * safezoneW + safezoneX;
				y = 0.934779 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1200: RscPictureGUI
			{
				idc = 1401;
				text = "\z\addons\zero_code\gui\stats_kills_zombie_ca.paa";
				x = 0.044687 * safezoneW + safezoneX;
				y = 0.876025 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
		};
		class Controls
		{
			class RscText1: RscStructuredTextGUI
			{
				idc = 1410;
				text = "10";
				x = (0.044687 * safezoneW + safezoneX) - 0.01;
				y = 0.934779 * safezoneH + safezoneY;
				w = 0.08;
				h = 0.08;
			};
			class RscText2: RscStructuredTextGUI
			{
				idc = 1411;
				text = "1000";
				x = (0.044687 * safezoneW + safezoneX) - 0.01;
				y = 0.876025 * safezoneH + safezoneY;
				w = 0.08;
				h = 0.08;
			};
		};
	};

	class playerStatusWaiting
	{
		idd = 6901;
		movingEnable = 0;
		duration = 100000;
		name = "playerStatusWaiting";
		onLoad = "uiNamespace setVariable ['DAYZ_GUI_waiting', _this select 0];";
		class ControlsBackground {
			class RscText_1402: RscPictureGUI
			{
				idc = 1402;
				text = "#(argb,8,8,3)color(1,1,1,1)";
				x = 0.473572 * safezoneW + safezoneX;
				y = 0.418158 * safezoneH + safezoneY;
				w = 0.0634286 * safezoneW;
				h = 0.136829 * safezoneH;
				colorText[] = {1,1,1,1};
			};
			class RscText_1400: RscPictureGUI
			{
				idc = 1400;
				text = "#(argb,8,8,3)color(1,1,1,1)";
				x = 0.473572 * safezoneW + safezoneX;
				y = 0.418158 * safezoneH + safezoneY;
				w = 0.0634286 * safezoneW;
				h = 0; //0.136829 * safezoneH;
				colorText[] = {0,0,0,1};
			};
		};
		class Controls
		{
			class RscPicture_1401: RscPictureGUI
			{
				idc = 1401;
				text = "\z\addons\zero_code\gui\status_waiting_ca.paa";
				x = 0.434999 * safezoneW + safezoneX;
				y = 0.392207 * safezoneH + safezoneY;
				w = 0.141 * safezoneW;
				h = 0.188013 * safezoneH;
				colorText[] = {0.38,0.63,0.26,1};
			};
		};
	};

	class playerStatusGUI
	{
		idd = 6900;
		movingEnable = 0;
		duration = 100000;
		name = "statusBorder";
		onLoad = "uiNamespace setVariable ['DAYZ_GUI_display', _this select 0];";
		class ControlsBackground
		{
			//KILL ICON
			class hud_faceStatsKills_Status: RscPictureGUI
			{
				idc = 13371;
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.73 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
				shadow = 2;
				colorText[] = {1,1,1,1};
				text = "\z\addons\zero_code\gui\status_murders.paa";
			};
			//ZEDKILL ICON
			class hud_faceStatsZedKills_Status: RscPictureGUI
			{
				idc = 13372;
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.657 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
				shadow = 2;
				colorText[] = {1,1,1,1};
				text = "\z\addons\zero_code\gui\status_zombiekills.paa";
			};

			/*class RscPicture_1200: RscPictureGUI
			{
				idc = 1200;
				text = "\z\addons\zero_code\gui\status_blood_border_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.93 * safezoneH + safezoneY; //1
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1201: RscPictureGUI
			{
				idc = 1201;
				text = "\z\addons\zero_code\gui\status_food_border_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.86 * safezoneH + safezoneY;//2
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1202: RscPictureGUI
			{
				idc = 1202;
				text = "\z\addons\zero_code\gui\status_thirst_border_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.79 * safezoneH + safezoneY; //3
				w = 0.06;
				h = 0.08;
			};*/
			class RscPicture_1203: RscPictureGUI
			{
				idc = 1203;
				text = "\z\addons\zero_code\gui\status_fracture_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.58 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
				colorText[] = {1,1,1,1};
			};
			class RscPicture_1204: RscPictureGUI
			{
				idc = 1204;
				text = "\z\addons\zero_code\gui\status_connection_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.51 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
				colorText[] = {1,1,1,1};
			};
			class RscPicture_1205: RscPictureGUI
			{
				idc = 1205;
				text = "\z\addons\zero_code\gui\status_ear_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.30 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1206: RscPictureGUI
			{
				idc = 1206;
				text = "\z\addons\zero_code\gui\status_eye_ca.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.37 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
		};

		class Controls
		{
			//bloodText
			class hud_faceStatsBloodText_Status: RscTextGUI
			{
				idc = 13380;
				x = 0.91 * safezoneW + safezoneX;
				y = 0.95 * safezoneH + safezoneY;
				w = 0.1;
				h = 0.08;
				colorText[] = {1,1,1,1};
				text = "100";
			};
			//killtext
			class hud_faceStatsKillsText_Status: RscTextGUI
			{
				idc = 13381;
				x = 0.91 * safezoneW + safezoneX;
				y = 0.745 * safezoneH + safezoneY;
				w = 0.1;
				h = 0.08;
				colorText[] = {1,1,1,1};
				text = "0";
			};
			//zedKillText
			class hud_faceStatsZedKillText_Status: RscTextGUI
			{
				idc = 13382;
				x = 0.91 * safezoneW + safezoneX;
				y = 0.67 * safezoneH + safezoneY;
				w = 0.1;
				h = 0.08;
				colorText[] = {1,1,1,1};
				text = "0";
			};

			class RscPicture_1300: RscPictureGUI
			{
				idc = 1300;
				text = "\z\addons\zero_code\gui\status_blood_normal.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.93 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1301: RscPictureGUI
			{
				idc = 1301;
				text = "\z\addons\zero_code\gui\status_food_3.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.86 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1302: RscPictureGUI
			{
				idc = 1302;
				text = "\z\addons\zero_code\gui\status_thirst_3.paa";
				x = 0.955313 * safezoneW + safezoneX;
				y = 0.79 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1304: RscPictureGUI
			{
				idc = 1304;
				text = "";
				x = 0.935313 * safezoneW + safezoneX;
				y = 0.3 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
			class RscPicture_1305: RscPictureGUI
			{
				idc = 1305;
				text = "";
				x = 0.935313 * safezoneW + safezoneX;
				y = 0.37 * safezoneH + safezoneY;
				w = 0.06;
				h = 0.08;
			};
		};
	};
};