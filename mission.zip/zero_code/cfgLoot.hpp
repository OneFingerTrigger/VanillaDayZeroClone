class CfgLoot
{
	trash[] =
	{
		{
			"TrashTinCan",
			"TrashJackDaniels",
			"ItemSodaEmpty"
		},
		{
			2.00,	// TrashTinCan
			0.30,	// TrashJackDaniels
			1.00	// ItemSodaEmpty
		}
	};

	residentialtrash[] =
	{
		{
			"TrashTinCan",
			"TrashJackDaniels",
			"ItemSodaEmpty",
			"ItemTrashToiletpaper",
			"ItemTrashRazor"
		},
		{
			1.00,	// TrashTinCan
			0.10,	// TrashJackDaniels
			0.50,	// ItemSodaEmpty
			0.40,	// ItemTrashToiletpaper
			0.20	// ItemTrashRazor
		}
	};

	churchtrash[] =
	{
		{
			"TrashTinCan",
			"TrashJackDaniels",
			"ItemSodaEmpty",
			"ItemBookBible"
		},
		{
			1.00,	// TrashTinCan
			0.10,	// TrashJackDaniels
			0.50,	// ItemSodaEmpty
			0.40	// ItemBookBible
		}
	};

	civilian[] =
	{
		{
			"TrashTinCan",
			"TrashJackDaniels",
			"ItemSodaEmpty",
			"ItemSodaCoke",
			"ItemSodaPepsi",
			"FoodCanBakedBeans",
			"FoodCanSardines",
			"FoodCanFrankBeans",
			"FoodCanPasta",
			"8Rnd_9x18_Makarov",
			"DZero_20Rnd_9x18_aps",
			"DZero_8Rnd_9x19_P38",
			"DZero_7Rnd_32cal_ppk",
			"DZero_8Rnd_45cal_m1911",
			"2Rnd_shotgun_74Slug",
			"2Rnd_shotgun_74Pellets",
			"ItemBandage",
			"ItemPainkiller"
		},
		{
			0.09,	// TrashTinCan
			0.09,	// TrashJackDaniels
			0.09,	// ItemSodaEmpty
			0.12,	// ItemSodaCoke
			0.09,	// ItemSodaPepsi
			0.05,	// FoodCanBakedBeans
			0.05,	// FoodCanSardines
			0.05,	// FoodCanFrankBeans
			0.05,	// FoodCanPasta
			0.07,	// 8Rnd_9x18_Makarov
			0.06,	// DZero_20Rnd_9x18_aps
			0.05,	// DZero_8Rnd_9x19_P38
			0.04,	// DZero_7Rnd_32cal_ppk
			0.03,	// DZero_8Rnd_45cal_m1911
			0.05,	// 2Rnd_shotgun_74Slug
			0.05,	// 2Rnd_shotgun_74Pellets
			0.06,	// ItemBandage
			0.06	// ItemPainkiller
		}
	};

	food[] =
	{
		{
			"TrashTinCan",
			"TrashJackDaniels",
			"ItemSodaEmpty",
			"ItemSodaCoke",
			"ItemSodaPepsi",
			"FoodCanBakedBeans",
			"FoodCanSardines",
			"FoodCanFrankBeans",
			"FoodCanPasta",
			"FoodPistachio",
			"FoodNutmix"
		},
		{
			0.15,	// TrashTinCan
			0.07,	// TrashJackDaniels
			0.15,	// ItemSodaEmpty
			0.12,	// ItemSodaCoke
			0.12,	// ItemSodaPepsi
			0.09,	// FoodCanBakedBeans
			0.09,	// FoodCanSardines
			0.09,	// FoodCanFrankBeans
			0.09,	// FoodCanPasta
			0.09,	// FoodPistachio
			0.04	// FoodNutmix
		}
	};

	generic[] =
	{
		{
			"TrashTinCan",
			"ItemSodaEmpty",
			"ItemSodaCoke",
			"ItemSodaPepsi",
			"TrashJackDaniels",
			"FoodCanBakedBeans",
			"FoodCanSardines",
			"FoodCanFrankBeans",
			"FoodCanPasta",
			"ItemWaterbottleUnfilled",
			"ItemWaterbottle",
			"ItemBandage",
			"DZero_8Rnd_45cal_m1911",
			"5x_22_LR_17_HMR",
			"10x_303",
			"DZero_10Rnd_762x39_SKS",
			"DZero_6Rnd_357_Mag",
			"2Rnd_shotgun_74Slug",
			"2Rnd_shotgun_74Pellets",
			"8Rnd_9x18_Makarov",
			"15Rnd_W1866_Slug",
			"BoltWood",
			"HandRoadFlare",
			"ItemPainkiller",
			"HandChemGreen"
		},
		{
			0.06,	// TrashTinCan
			0.06,	// ItemSodaEmpty
			0.06,	// ItemSodaCoke
			0.04,	// ItemSodaPepsi
			0.04,	// TrashJackDaniels
			0.01,	// FoodCanBakedBeans
			0.01,	// FoodCanSardines
			0.01,	// FoodCanFrankBeans
			0.01,	// FoodCanPasta
			0.01,	// ItemWaterbottleUnfilled
			0.01,	// ItemWaterbottle
			0.11,	// ItemBandage
			0.03,	// DZero_8Rnd_45cal_m1911
			0.01,	// 5x_22_LR_17_HMR
			0.04,	// 10x_303
			0.04,	// DZero_10Rnd_762x39_SKS
			0.04,	// DZero_6Rnd_357_Mag
			0.05,	// 2Rnd_shotgun_74Slug
			0.05,	// 2Rnd_shotgun_74Pellets
			0.09,	// 8Rnd_9x18_Makarov
			0.02,	// 15Rnd_W1866_Slug
			0.04,	// BoltWood
			0.07,	// HandRoadFlare
			0.02,	// ItemPainkiller
			0.02	// HandChemGreen
		}
	};

	genericru[] =
	{
		{
			"TrashTinCan",
			"ItemSodaEmpty",
			"ItemSodaCoke",
			"ItemSodaPepsi",
			"TrashJackDaniels",
			"FoodCanBakedBeans",
			"FoodCanSardines",
			"FoodCanFrankBeans",
			"FoodCanPasta",
			"ItemWaterbottleUnfilled",
			"ItemWaterbottle",
			"ItemBandage",
			"30Rnd_545x39_AK",
			"30Rnd_545x39_AKSD",
			"64Rnd_9x19_Bizon",
			"64Rnd_9x19_SD_Bizon",
			"8Rnd_9x18_Makarov",
			"8Rnd_9x18_MakarovSD",
			"DZero_20Rnd_9x18_aps",
			"DZero_20Rnd_9x18_apsSD",
			"HandRoadFlare",
			"ItemPainkiller",
			"HandChemGreen"
		},
		{
			0.06,	// TrashTinCan
			0.06,	// ItemSodaEmpty
			0.06,	// ItemSodaCoke
			0.04,	// ItemSodaPepsi
			0.04,	// TrashJackDaniels
			0.01,	// FoodCanBakedBeans
			0.01,	// FoodCanSardines
			0.01,	// FoodCanFrankBeans
			0.01,	// FoodCanPasta
			0.01,	// ItemWaterbottleUnfilled
			0.01,	// ItemWaterbottle
			0.11,	// ItemBandage
			0.03,	// 30Rnd_545x39_AK
			0.01,	// 30Rnd_545x39_AKSD
			0.04,	// 64Rnd_9x19_Bizon
			0.04,	// 64Rnd_9x19_SD_Bizon
			0.05,	// 8Rnd_9x18_Makarov
			0.05,	// 8Rnd_9x18_MakarovSD
			0.09,	// DZero_20Rnd_9x18_aps
			0.05,	// DZero_20Rnd_9x18_apsSD
			0.07,	// HandRoadFlare
			0.02,	// ItemPainkiller
			0.02	// HandChemGreen
		}
	};

	genericus[] =
	{
		{
			"TrashTinCan",
			"ItemSodaEmpty",
			"ItemSodaCoke",
			"ItemSodaPepsi",
			"TrashJackDaniels",
			"FoodCanBakedBeans",
			"FoodCanSardines",
			"FoodCanFrankBeans",
			"FoodCanPasta",
			"ItemWaterbottleUnfilled",
			"ItemWaterbottle",
			"ItemBandage",
			"30Rnd_556x45_Stanag",
			"5Rnd_762x51_M24",
			"8Rnd_B_Beneli_74Slug",
			"8Rnd_B_Beneli_Pellets",
			"30Rnd_9x19_MP5",
			"DZero_50Rnd_57x28_P90Mag",
			"15Rnd_9x19_M9",
			"15Rnd_9x19_M9SD",
			"DZero_8Rnd_45calm1911SD",
			"HandRoadFlare",
			"ItemPainkiller",
			"HandChemGreen"
		},
		{
			0.06,	// TrashTinCan
			0.06,	// ItemSodaEmpty
			0.06,	// ItemSodaCoke
			0.04,	// ItemSodaPepsi
			0.04,	// TrashJackDaniels
			0.01,	// FoodCanBakedBeans
			0.01,	// FoodCanSardines
			0.01,	// FoodCanFrankBeans
			0.01,	// FoodCanPasta
			0.01,	// ItemWaterbottleUnfilled
			0.01,	// ItemWaterbottle
			0.11,	// ItemBandage
			0.03,	// 30Rnd_556x45_Stanag
			0.01,	// 5Rnd_762x51_M24
			0.04,	// 8Rnd_B_Beneli_74Slug
			0.04,	// 8Rnd_B_Beneli_Pellets
			0.05,	// 30Rnd_9x19_MP5
			0.05,	// DZero_50Rnd_57x28_P90Mag
			0.09,	// 15Rnd_9x19_M9
			0.05,	// 15Rnd_9x19_M9SD
			0.05,   //DZero_8Rnd_45calm1911SD
			0.07,	// HandRoadFlare
			0.02,	// ItemPainkiller
			0.02	// HandChemGreen
		}
	};

	genericpol[] =
	{
		{
			"TrashTinCan",
			"ItemSodaEmpty",
			"ItemSodaCoke",
			"ItemSodaPepsi",
			"TrashJackDaniels",
			"ItemWaterbottleUnfilled",
			"ItemWaterbottle",
			"ItemBandage",
			"8Rnd_B_Beneli_74Slug",
			"8Rnd_B_Beneli_Pellets",
			"30Rnd_9x19_MP5",
			"DZero_25Rnd_45ACP_UMPMag",
			"15Rnd_9x19_M9",
			"HandRoadFlare",
			"ItemPainkiller",
			"HandChemGreen",
			"DZero_8Rnd_762_tt33",
			"DZero_20Rnd_32cal_vz61",
			"DZero_8Rnd_45cal_m1911",
			"1Rnd_HE_GP25",
			"FlareWhite_GP25",
			"FlareGreen_GP25",
			"FlareRed_GP25",
			"FlareYellow_GP25",
			"1Rnd_SMOKE_GP25",
			"1Rnd_SmokeRed_GP25",
			"1Rnd_SmokeGreen_GP25",
			"1Rnd_SmokeYellow_GP25",
			"30Rnd_545x39_AK"
		},
		{
			0.06,	// TrashTinCan
			0.06,	// ItemSodaEmpty
			0.06,	// ItemSodaCoke
			0.04,	// ItemSodaPepsi
			0.04,	// TrashJackDaniels
			0.01,	// ItemWaterbottleUnfilled
			0.01,	// ItemWaterbottle
			0.11,	// ItemBandage
			0.04,	// 8Rnd_B_Beneli_74Slug
			0.04,	// 8Rnd_B_Beneli_Pellets
			0.05,	// 30Rnd_9x19_MP5
			0.05,	// DZero_25Rnd_45ACP_UMPMag
			0.09,	// 15Rnd_9x19_M9
			0.07,	// HandRoadFlare
			0.02,	// ItemPainkiller
			0.02,	// HandChemGreen
			0.07,	// DZero_8Rnd_762_tt33
			0.05,	// DZero_20Rnd_32cal_vz61
			0.10,	// DZero_8Rnd_45cal_m1911
			0.01,	// 1Rnd_HE_GP25
			0.01,	// FlareWhite_GP25
			0.01,	// FlareGreen_GP25
			0.01,	// FlareRed_GP25
			0.01,	// FlareYellow_GP25
			0.02,	// 1Rnd_SMOKE_GP25
			0.01,	// 1Rnd_SmokeRed_GP25
			0.01,	// 1Rnd_SmokeGreen_GP25
			0.01,	// 1Rnd_SmokeYellow_GP25
			0.06	// 30Rnd_545x39_AK
		}
	};

	medical[] =
	{
		{
			"ItemBandage",
			"ItemPainkiller",
			"ItemMorphine",
			"ItemEpinephrine"
		},
		{
			1.00,	// ItemBandage
			0.50,	// ItemPainkiller
			0.50,	// ItemMorphine
			0.20	// ItemEpinephrine
		}
	};

	hospital[] =
	{
		{
			"ItemBandage",
			"ItemPainkiller",
			"ItemMorphine",
			"ItemEpinephrine",
			"ItemBloodbag"
		},
		{
			0.43,	// ItemBandage
			0.17,	// ItemPainkiller
			0.13,	// ItemMorphine
			0.15,	// ItemEpinephrine
			0.15	// ItemBloodbag
		}
	};

	militaryru[] =
	{
		{
			"ItemWaterbottleUnfilled",
			"FoodMRE",
			"ItemBandage",
			"ItemPainkiller",
			"ItemMorphine",
			"8Rnd_9x18_Makarov",
			"8Rnd_9x18_MakarovSD",
			"DZero_20Rnd_9x18_aps",
			"DZero_20Rnd_9x18_apsSD",
			"64Rnd_9x19_Bizon",
			"64Rnd_9x19_SD_Bizon",
			"30Rnd_545x39_AK",
			"30Rnd_545x39_AKSD",
			"30Rnd_762x39_AK47",
			"DZero_30Rnd_762x39_magSD",
			"20Rnd_556x45_Stanag",
			"30Rnd_556x45_Stanag",
			"DZero_100Rnd_762x54_PK",
			"DZero_75Rnd_762x39_mag",
			"DZero_45Rnd_545x39_mag",
			"10Rnd_762x54_SVD",
			"8Rnd_B_Beneli_74Slug",
			"8Rnd_B_Beneli_Pellets",
			"1Rnd_HE_GP25",
			"FlareWhite_GP25",
			"FlareGreen_GP25",
			"FlareRed_GP25",
			"FlareYellow_GP25",
			"1Rnd_SMOKE_GP25",
			"1Rnd_SmokeRed_GP25",
			"1Rnd_SmokeGreen_GP25",
			"1Rnd_SmokeYellow_GP25",
			"HandGrenade_East",
			"SmokeShell",
			"SmokeShellYellow",
			"SmokeShellOrange",
			"SmokeShellRed",
			"HandChemRed"
		},
		{
			0.05,	// ItemWaterbottleUnfilled
			0.10,	// FoodMRE
			0.05,	// ItemBandage
			0.04,	// ItemPainkiller
			0.03,	// ItemMorphine
			0.08,	// 8Rnd_9x18_Makarov
			0.04,	// 8Rnd_9x18_MakarovSD
			0.06,	// DZero_20Rnd_9x18_aps
			0.02,	// DZero_20Rnd_9x18_apsSD
			0.04,	// 64Rnd_9x19_Bizon
			0.02,	// 64Rnd_9x19_SD_Bizon
			0.06,	// 30Rnd_545x39_AK
			0.02,	// 30Rnd_545x39_AKSD
			0.03,	// 30Rnd_762x39_AK47
			0.01,	// DZero_30Rnd_762x39_magSD
			0.04,	// 20Rnd_556x45_Stanag
			0.02,	// 30Rnd_556x45_Stanag 
			0.01,	// DZero_100Rnd_762x54_PK
			0.02,	// DZero_75Rnd_762x39_mag
			0.01,	// DZero_45Rnd_545x39_mag
			0.01,	// 10Rnd_762x54_SVD
			0.04,	// 8Rnd_B_Beneli_74Slug
			0.02,	// 8Rnd_B_Beneli_Pellets
			0.01,	// 1Rnd_HE_GP25
			0.01,	// FlareWhite_GP25
			0.01,	// FlareGreen_GP25
			0.01,	// FlareRed_GP25
			0.01,	// FlareYellow_GP25
			0.02,	// 1Rnd_SMOKE_GP25
			0.01,	// 1Rnd_SmokeRed_GP25
			0.01,	// 1Rnd_SmokeGreen_GP25
			0.01,	// 1Rnd_SmokeYellow_GP25
			0.02,	// HandGrenade_East
			0.04,	// SmokeShell
			0.04,	// SmokeShellYellow
			0.04,	// SmokeShellOrange
			0.04,	// SmokeShellRed
			0.04	// HandChemRed
		}
	};

	militaryus[] =
	{
		{
			"ItemWaterbottleUnfilled",
			"FoodMRE",
			"ItemBandage",
			"ItemPainkiller",
			"ItemMorphine",
			"15Rnd_9x19_M9",
			"15Rnd_9x19_M9SD",
			"DZero_8Rnd_45calm1911SD",
			"DZero_17Rnd_9x19_g17",
			"DZero_17Rnd_9x19_g17SD",
			"DZero_20Rnd_9x19_M93",
			"DZero_32Rnd_9x19_Muzi",
			"30Rnd_9x19_MP5",
			"30Rnd_9x19_MP5SD",
			"DZero_50Rnd_57x28_P90Mag",
			"DZero_50Rnd_57x28_P90MagSD",
			"30Rnd_556x45_Stanag",
			"30Rnd_556x45_StanagSD",
			"100Rnd_556x45_BetaCMag",
			"DZero_100Rnd_762x51_M240",
			"200Rnd_556x45_M249",
			"DZero_20Rnd_762x51_G3",
			"20Rnd_762x51_DMR",
			"5Rnd_762x51_M24",
			"5Rnd_86x70_L115A1",
			"8Rnd_B_Beneli_74Slug",
			"8Rnd_B_Beneli_Pellets",
			"1Rnd_HE_M203",
			"FlareWhite_M203",
			"FlareGreen_M203",
			"FlareRed_M203",
			"FlareYellow_M203",
			"1Rnd_Smoke_M203",
			"1Rnd_SmokeRed_M203",
			"1Rnd_SmokeGreen_M203",
			"1Rnd_SmokeYellow_M203",
			"HandGrenade_West",
			"SmokeShell",
			"SmokeShellGreen",
			"SmokeShellBlue",
			"SmokeShellPurple",
			"HandChemBlue"
		},
		{
			0.05,	// ItemWaterbottleUnfilled
			0.10,	// FoodMRE
			0.05,	// ItemBandage
			0.04,	// ItemPainkiller
			0.03,	// ItemMorphine
			0.08,	// 15Rnd_9x19_M9
			0.04,	// 15Rnd_9x19_M9SD
			0.04,   //DZero_8Rnd_45calm1911SD
			0.08,	// DZero_17Rnd_9x19_g17
			0.04,	// DZero_17Rnd_9x19_g17SD
			0.04,	// DZero_20Rnd_9x19_M93
			0.02,	// DZero_32Rnd_9x19_Muzi
			0.04,	// 30Rnd_9x19_MP5
			0.02,	// 30Rnd_9x19_MP5SD
			0.04,	// DZero_50Rnd_57x28_P90Mag
			0.02,	// DZero_50Rnd_57x28_P90MagSD
			0.06,	// 30Rnd_556x45_Stanag
			0.02,	// 30Rnd_556x45_StanagSD
			0.01,	// 100Rnd_556x45_BetaCMag
			0.02,	// DZero_100Rnd_762x51_M240
			0.01,	// 200Rnd_556x45_M249
			0.02,	// DZero_20Rnd_762x51_G3
			0.02,	// 20Rnd_762x51_DMR
			0.02,	// 5Rnd_762x51_M24
			0.01,	// 5Rnd_86x70_L115A1
			0.04,	// 8Rnd_B_Beneli_74Slug
			0.02,	// 8Rnd_B_Beneli_Pellets
			0.01,	// 1Rnd_HE_M203
			0.01,	// FlareWhite_M203
			0.01,	// FlareGreen_M203
			0.01,	// FlareRed_M203
			0.01,	// FlareYellow_M203
			0.02,	// 1Rnd_Smoke_M203
			0.01,	// 1Rnd_SmokeRed_M203
			0.01,	// 1Rnd_SmokeGreen_M203
			0.01,	// 1Rnd_SmokeYellow_M203
			0.02,	// HandGrenade_West
			0.04,	// SmokeShell
			0.04,	// SmokeShellGreen
			0.04,	// SmokeShellBlue
			0.04,	// SmokeShellPurple
			0.04	// HandChemBlue
		}
	};

	militaryger[] =
	{
		{
			"ItemWaterbottleUnfilled",
			"FoodMRE",
			"ItemBandage",
			"ItemPainkiller",
			"ItemMorphine",
			"30Rnd_9x19_MP5",
			"30Rnd_9x19_MP5SD",
			"HandGrenade_West",
			"SmokeShell",
			"SmokeShellGreen",
			"SmokeShellBlue",
			"SmokeShellPurple",
			"HandChemBlue",
			"DZero_20Rnd_762x51_G3",
			"DZero_12Rnd_45cal_usp",
			"DZero_12Rnd_45caluspSD",
			"5Rnd_762x51_M24",
			"30Rnd_556x45_G36",
			"30Rnd_556x45_G36SD"
		},
		{
			0.05,	// ItemWaterbottleUnfilled
			0.10,	// FoodMRE
			0.05,	// ItemBandage
			0.04,	// ItemPainkiller
			0.03,	// ItemMorphine
			0.04,	// 30Rnd_9x19_MP5
			0.02,	// 30Rnd_9x19_MP5SD
			0.02,	// HandGrenade_West
			0.04,	// SmokeShell
			0.04,	// SmokeShellGreen
			0.04,	// SmokeShellBlue
			0.04,	// SmokeShellPurple
			0.04,	// HandChemBlue
			0.05,	// DZero_20Rnd_762x51_G3
			0.05,	// DZero_12Rnd_45cal_usp
			0.02,	// DZero_12Rnd_45caluspSD
			0.02,	// 5Rnd_762x51_M24
			0.04,	// 30Rnd_556x45_G36
			0.01	// 30Rnd_556x45_G36SD
		}
	};
	
	militaryuk[] =
	{
		{
			"ItemWaterbottleUnfilled",
			"FoodMRE",
			"ItemBandage",
			"ItemPainkiller",
			"ItemMorphine",
			"HandGrenade_West",
			"SmokeShell",
			"SmokeShellGreen",
			"SmokeShellBlue",
			"SmokeShellPurple",
			"HandChemBlue",
			"5Rnd_86x70_L115A1",
			"1Rnd_HE_M203",
			"FlareWhite_M203",
			"FlareGreen_M203",
			"FlareRed_M203",
			"FlareYellow_M203",
			"1Rnd_Smoke_M203",
			"1Rnd_SmokeRed_M203",
			"1Rnd_SmokeGreen_M203",
			"1Rnd_SmokeYellow_M203",
			"30Rnd_556x45_Stanag",
			"30Rnd_556x45_StanagSD",
			"100Rnd_556x45_BetaCMag",
			"DZero_13Rnd_9x19_L9A1",
			"DZero_20Rnd_762x51_L1A1"
			
		},
		{
			0.05,	// ItemWaterbottleUnfilled
			0.10,	// FoodMRE
			0.05,	// ItemBandage
			0.04,	// ItemPainkiller
			0.03,	// ItemMorphine
			0.02,	// HandGrenade_West
			0.04,	// SmokeShell
			0.04,	// SmokeShellGreen
			0.04,	// SmokeShellBlue
			0.04,	// SmokeShellPurple
			0.04,	// HandChemBlue
			0.01,	// 5Rnd_86x70_L115A1
			0.01,	// 1Rnd_HE_M203
			0.01,	// FlareWhite_M203
			0.01,	// FlareGreen_M203
			0.01,	// FlareRed_M203
			0.01,	// FlareYellow_M203
			0.02,	// 1Rnd_Smoke_M203
			0.01,	// 1Rnd_SmokeRed_M203
			0.01,	// 1Rnd_SmokeGreen_M203
			0.01,	// 1Rnd_SmokeYellow_M203
			0.06,	// 30Rnd_556x45_Stanag
			0.02,	// 30Rnd_556x45_StanagSD
			0.01,	// 100Rnd_556x45_BetaCMag
			0.15,	// DZero_13Rnd_9x19_L9A1
			0.05	// DZero_20Rnd_762x51_L1A1
			
		}
	};	
	policeman[] =
	{
		{
			"ItemBandage",
			"DZero_8Rnd_45cal_m1911",
			"DZero_6Rnd_357_Mag",
			"DZero_6Rnd_44_Mag",
			"8Rnd_B_Beneli_74Slug",
			"HandRoadFlare"
		},
		{
			1.00,	// ItemBandage
			0.80,	// DZero_8Rnd_45cal_m1911
			0.30,	// DZero_6Rnd_357_Mag
			0.30,	// DZero_6Rnd_44_Mag
			0.50,	// 8Rnd_B_Beneli_74Slug
			0.30	// HandRoadFlare
		}
	};
	priest[] =
	{
		{
			"ItemBandage",
			"TrashJackDaniels",
			"ItemBookBible",
			"ItemPainkiller"
		},
		{
			0.50,	// ItemBandage
			0.80,	// TrashJackDaniels
			1.00,	// ItemBookBible
			0.50	// ItemPainkiller
		}
	};
	hunter[] =
	{
		{
			"ItemBandage",
			"DZero_6Rnd_44_Mag",
			"DZero_8Rnd_45cal_m1911",
			"10x_303",
			"DZero_10Rnd_762x39_SKS",
			"ItemWaterbottleUnfilled",
			"BoltWood",
			"FoodMRE",
			"FoodNutmix"
		},
		{
			1.00,	// ItemBandage
			0.50,	// DZero_6Rnd_44_Mag
			0.20,	// DZero_8Rnd_45cal_m1911
			0.50,	// 10x_303
			0.40,	// DZero_10Rnd_762x39_SKS
			0.20,	// ItemWaterbottleUnfilled
			1.00,	// BoltWood
			0.04,	// FoodMRE
			0.10	// FoodNutmix
		}
	};
};