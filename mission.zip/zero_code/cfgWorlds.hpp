class CfgWorlds
{
	initWorld = "Chernarus";
	demoWorld = "Chernarus";

	class CAWorld;	
	class Chernarus : CAWorld
	{
		cutscenes[] = {"ChernarusIntro1"};
	};
};
