/*
        Created exclusively for ArmA2:OA - DayZMod.
        Please request permission to use/alter/distribute from project leader (R4Z0R49) AND the author (facoptere@gmail.com)
*/

// These RE commands will be cancelled once init.sqf is exec'ed on client or server
#ifndef REMOVED_LIB
#define REMOVED_LIB  [ "addAction", "addEventHandler", "addMagazine", "addMagazineCargo", "addWeapon", \
"addWeaponCargo", "addWPCur", "animate", "callVar", "clearMagazineCargo", "clearWeaponCargo", "createDiaryRecord", \
"createMarkerLocal", "createSimpleTask", "createTaskSet", "debugLog", "deleteWP", "enableSimulation", "endMission", \
"execFSM", "fadeMusic", "fadeSound", "failMission", "globalChat", "globalRadio", "groupChat", "groupRadio", \
"hideObject", "hint", "hintC", "kbAddTopic", "kbreact", "kbRemoveTopic", "kbtell", "land", "move", "moveIn", \
"playAction", "playActionNow", "playMoveNow", "playMusic", "playSound", "removeAction", \
"removeAllWeapons", "setCaptive", "setCurrentTask", "setCurrentTaskArrays", "setDate", "setDir", "setGroupID", \
"setMarkerPosLocal", "setObjectTexture", "setSimpleTaskDescription", "setTaskState", "setWPdesc", "setWPtype", \
"showCommandingMenu", "sideChat", "sideRadio", "skipTime", "spawn", "switchAction", "switchCamera", "taskHint", \
"titleCut"]
#endif

// Allowed commands
#ifndef TRACED_LIB
#define TRACED_LIB [ "execVM", "JIPexec", "JIPrequest", "say", "playMove", "switchMove", "titleText" ]
// uncomment following line to log all incoming allowed RE
// #define RESEC_VERBOSE
#endif

// Special logic for execVM, only these whitelisted scripts will be spawned
#ifndef WHITELISTED_EXECVM
#define WHITELISTED_EXECVM [ ""ca\Modules\Functions\init.sqf"" ]
// uncomment and put in the array above if you want your server be able to kick players (not used in DayZ for now)
//""ca\Modules\MP\data\scriptCommands\endMission.sqf"" 
#endif

#define Stringify(macro) #macro
