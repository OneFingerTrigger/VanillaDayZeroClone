//5.45x39mm
AmmoBoxRU1[] =
{
	{Loot_MAGAZINE,		6,		30Rnd_545x39_AK},
	{Loot_MAGAZINE,		3,		30Rnd_545x39_AKSD},
	{Loot_MAGAZINE,		1,		75Rnd_545x39_RPK}
};

//7.62x39mm
AmmoBoxRU2[] =
{
	{Loot_MAGAZINE,		9,		30Rnd_762x39_AK47},
	{Loot_MAGAZINE,		1,		75Rnd_762x39_RPK}
};

//7.62x54Rmm
AmmoBoxRU3[] =
{
	{Loot_MAGAZINE,		9,		10Rnd_762x54_SVD},
	{Loot_MAGAZINE,		1,		100Rnd_762x54_PK}
};

//5.56x45mm
AmmoBoxUS1[] =
{
	{Loot_MAGAZINE,		14,		30Rnd_556x45_Stanag},
	{Loot_MAGAZINE,		8,		30Rnd_556x45_StanagSD},
	{Loot_MAGAZINE,		1.5,	100Rnd_556x45_M249},
	{Loot_MAGAZINE,		0.5,	200Rnd_556x45_M249}
};

//7.62x51mm
AmmoBoxUS2[] =
{
	{Loot_MAGAZINE,		9,		20Rnd_762x51_DMR},
	{Loot_MAGAZINE,		1,		100Rnd_762x51_M240}
};

//5.56x45mm
AmmoBoxEU1[] =
{
	{Loot_MAGAZINE,		14,		30Rnd_556x45_G36},
	{Loot_MAGAZINE,		8,		30Rnd_556x45_G36SD},
	{Loot_MAGAZINE,		1.5,	100Rnd_556x45_M249},
	{Loot_MAGAZINE,		0.5,	200Rnd_556x45_M249}
};

//7.62x51mm
AmmoBoxEU2[] =
{
	{Loot_MAGAZINE,		9,		20Rnd_762x51_FNFAL},
	{Loot_MAGAZINE,		1,		100Rnd_762x51_M240},
	{Loot_MAGAZINE,		4,		5Rnd_86x70_L115A1}
};

//7.62x39mm
AmmoBoxCZ1[] =
{
	{Loot_MAGAZINE,		9,		30Rnd_762x39_SA58},
	{Loot_MAGAZINE,		1,		75Rnd_762x39_RPK}
};

//7.62x54Rmm
AmmoBoxCZ2[] =
{
	{Loot_MAGAZINE,		1,		50Rnd_762x54_UK59}
};

//GP-25
AmmoBoxRU4[] =
{
	{Loot_MAGAZINE,		3,		1Rnd_HE_GP25},
	{Loot_MAGAZINE,		0.5,	FlareWhite_GP25},
	{Loot_MAGAZINE,		0.5,	FlareGreen_GP25},
	{Loot_MAGAZINE,		1,		1Rnd_Smoke_GP25}
};

//M203
AmmoBoxUS3[] =
{
	{Loot_MAGAZINE,		3,		1Rnd_HE_M203},
	{Loot_MAGAZINE,		0.5,	FlareWhite_M203},
	{Loot_MAGAZINE,		0.5,	FlareGreen_M203},
	{Loot_MAGAZINE,		1,		1Rnd_Smoke_M203}
};

//Explosives
AmmoBoxRU5[] =
{
	{Loot_MAGAZINE,		2,		HandGrenade_East},
	{Loot_MAGAZINE,		1,		SmokeShell},
	{Loot_MAGAZINE,		1,		SmokeShellRed},
	{Loot_MAGAZINE,		1,		SmokeShellGreen},
	{Loot_MAGAZINE,		0.1,	PipeBomb}
};

//Explosives
AmmoBoxUS4[] =
{
	{Loot_MAGAZINE,		2,		HandGrenade_West},
	{Loot_MAGAZINE,		1,		SmokeShell},
	{Loot_MAGAZINE,		1,		SmokeShellRed},
	{Loot_MAGAZINE,		1,		SmokeShellGreen},
	{Loot_MAGAZINE,		0.3,	PipeBomb}
};