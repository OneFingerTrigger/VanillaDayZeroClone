MedicalLow[] =
{
	{Loot_MAGAZINE,		8,		ItemBandage},
	{Loot_MAGAZINE,		5,		ItemPainkiller},
	{Loot_MAGAZINE,		4,		ItemMorphine},
	{Loot_MAGAZINE,		3,		ItemEpinephrine}
};

MedicalHigh[] =
{
	{Loot_MAGAZINE,		5,		ItemMorphine},
	
	{Loot_GROUP,		6,		Bloodbags},
	
	{Loot_GROUP,		7,		MedicalLow}
};

MedicalBox[] =
{
	{Loot_MAGAZINE,		5,		ItemMorphine},
	
	{Loot_GROUP,		1,		Antibiotics},
	{Loot_GROUP,		15,		Bloodbags},
	
	{Loot_GROUP,		7,		MedicalLow}
};


Bloodbags[] =
{
	{Loot_MAGAZINE,		5,		ItemBloodbag},
	{Loot_MAGAZINE,		4,		ItemBloodbag},
	
	{Loot_MAGAZINE,		5,		ItemBloodbag},
	{Loot_MAGAZINE,		4,		ItemBloodbag},
	
	{Loot_MAGAZINE,		2,		ItemBloodbag},
	{Loot_MAGAZINE,		2,		ItemBloodbag},
	
	{Loot_MAGAZINE,		2,		ItemBloodbag},
	{Loot_MAGAZINE,		1,		ItemBloodbag}
};