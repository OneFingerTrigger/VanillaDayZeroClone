Generic[] =
{
//	{Loot_MAGAZINE,		1,		1Rnd_Arrow_Wood},
	
	{Loot_MAGAZINE,		1,		HandRoadFlare},
	{Loot_MAGAZINE,		1,		HandChemGreen},
	{Loot_MAGAZINE,		1,		HandChemBlue},
	{Loot_MAGAZINE,		1,		HandChemRed},
	
//	{Loot_MAGAZINE,		1,		ItemBookBible},
	
//	{Loot_MAGAZINE,		1,		equip_string},
//	{Loot_MAGAZINE,		1,		equip_duct_tape},
//	{Loot_MAGAZINE,		1,		equip_rope},
//	{Loot_MAGAZINE,		1,		equip_herb_box},
//	{Loot_MAGAZINE,		1,		equip_pvc_box},
//	{Loot_MAGAZINE,		1,		equip_lever},
//	{Loot_MAGAZINE,		1,		equip_rag},
	{Loot_MAGAZINE,		0.3,	equip_nails},
	{Loot_MAGAZINE,		1,		PartWoodPile},
	
	{Loot_GROUP,		1,		FuelCan}
};