Parts[] =
{
	{Loot_MAGAZINE,		5,		PartGeneric},
	{Loot_MAGAZINE,		3,		PartGlass},
	{Loot_MAGAZINE,		2,		PartFueltank},
	{Loot_MAGAZINE,		2,		PartWheel},
	{Loot_MAGAZINE,		1,		PartEngine}
};