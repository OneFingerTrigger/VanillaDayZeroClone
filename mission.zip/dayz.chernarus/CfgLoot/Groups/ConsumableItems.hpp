Matchbox[] =
{
	{Loot_WEAPON,		1,		ItemMatchbox},
	{Loot_WEAPON,		1,		Item5Matchbox},
	{Loot_WEAPON,		1,		Item4Matchbox},
	{Loot_WEAPON,		1,		Item3Matchbox},
	{Loot_WEAPON,		1,		Item2Matchbox},
	{Loot_WEAPON,		1,		Item1Matchbox},
	{Loot_WEAPON,		1,		ItemMatchboxEmpty}
};
