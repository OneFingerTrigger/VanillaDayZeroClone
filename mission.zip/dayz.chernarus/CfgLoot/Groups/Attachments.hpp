AttachmentsGeneric[] =
{
	{Loot_MAGAZINE,		3,		Attachment_BELT},
	{Loot_MAGAZINE,		1,		Attachment_SCOPED},
	{Loot_MAGAZINE,		2,		Attachment_FL},
	{Loot_MAGAZINE,		2,		Attachment_FL_Pist}
};

AttachmentsEast[] =
{
	{Loot_MAGAZINE,		2,		Attachment_Kobra},
	{Loot_MAGAZINE,		1,		Attachment_PSO1},
	{Loot_MAGAZINE,		3,		Attachment_Sup9},
	{Loot_MAGAZINE,		1,		Attachment_Sup545},
	{Loot_MAGAZINE,		2,		Attachment_GP25},
	{Loot_MAGAZINE,		2,		Attachment_Ghillie},
	{Loot_MAGAZINE,		3,		Attachment_SA58RIS}
};

AttachmentsWest[] =
{
	{Loot_MAGAZINE,		1.5,	Attachment_CCO},
	{Loot_MAGAZINE,		1,		Attachment_Holo},
	{Loot_MAGAZINE,		0.5,	Attachment_ACOG},
	{Loot_MAGAZINE,		3,		Attachment_Ghillie},
	{Loot_MAGAZINE,		2,		Attachment_M203},
	{Loot_MAGAZINE,		1,		Attachment_Sup556},
	{Loot_MAGAZINE,		3,		Attachment_Sup9},
	{Loot_MAGAZINE,		3,		Attachment_SA58RIS},
	{Loot_MAGAZINE,		3,		Attachment_MFL},
	{Loot_MAGAZINE,		3,		Attachment_MFL_Pist}
};
