ZombieCivilian[] =
{
	{Loot_GROUP,		6,		Consumable},
	{Loot_GROUP,		1,		AmmoCivilian},
	{Loot_MAGAZINE,		3,		ItemBandage},
	{Loot_MAGAZINE,		2,		ItemPainkiller},
	{Loot_MAGAZINE,		2,		ItemAntibacterialWipe}
};

ZombieCivilianViral[] =
{
	{Loot_GROUP,		10,		ZombieCivilian},
	{Loot_MAGAZINE,		1,		ItemAntibiotic1}
};