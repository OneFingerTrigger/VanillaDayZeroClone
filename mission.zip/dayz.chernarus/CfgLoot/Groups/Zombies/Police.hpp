ZombiePolice[] =
{
	{Loot_GROUP,		2,		Consumable},
	{Loot_MAGAZINE,		2,		7Rnd_45ACP_1911},
	{Loot_MAGAZINE,		3,		6Rnd_45ACP},
	{Loot_MAGAZINE,		1,		8Rnd_12Gauge_Buck},
	{Loot_MAGAZINE,		3,		HandRoadFlare}
};

ZombiePoliceViral[] =
{
	{Loot_GROUP,		10,		ZombiePolice},
	{Loot_MAGAZINE,		1,		ItemAntibiotic1}
};