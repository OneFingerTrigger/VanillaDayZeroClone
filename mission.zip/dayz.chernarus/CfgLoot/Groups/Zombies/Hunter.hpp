ZombieHunter[] =
{
	{Loot_GROUP,		4,		Consumable},
	{Loot_GROUP,		7,		AmmoCivilian},
	{Loot_MAGAZINE,		1,		1Rnd_Arrow_Wood}
};

ZombieHunterViral[] =
{
	{Loot_GROUP,		10,		ZombieHunter},
	{Loot_MAGAZINE,		1,		ItemAntibiotic1}
};