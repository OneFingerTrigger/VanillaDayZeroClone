Boat[] =
{
	{Loot_WEAPON,		1,		ItemFishingPole},
	{Loot_GROUP,		9,		Generic}
};