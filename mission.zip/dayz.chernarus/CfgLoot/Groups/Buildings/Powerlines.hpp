Powerlines[] =
{
	{Loot_MAGAZINE,		1,		PartGeneric}
};