Hangar[] =
{
	//Tools
	{Loot_WEAPON,		2,		ItemEtool},
	
	//Items
	{Loot_MAGAZINE,		2,		PartVRotor},
	{Loot_MAGAZINE,		2,		ItemSandbag},
	{Loot_MAGAZINE,		2,		ItemWire},
	{Loot_MAGAZINE,		2,		ItemTankTrap},
	
	//Groups
	{Loot_GROUP,		50,		Trash},
	{Loot_GROUP,		20,		Consumable},
	{Loot_GROUP,		10,		Generic},
	{Loot_GROUP,		5,		AttachmentsGeneric}
};