Office[] =
{
	//Tools
	{Loot_WEAPON,		8,		ItemWatch},
	{Loot_WEAPON,		6,		ItemMap},
	{Loot_WEAPON,		5,		ItemFlashlight},
	
	//Pistols
	{Loot_WEAPON,		4,		Makarov_DZ},
	{Loot_WEAPON,		3,		Revolver_DZ},
	{Loot_WEAPON,		2,		M1911_DZ},
	
	//Rifles
	//{Loot_WEAPON,		3,		MeleeBaseBallBat},
	
	//Backpacks
	{Loot_BACKPACK,		3,		DZ_BP_VestPouch},
	{Loot_BACKPACK,		2,		DZ_BP_Patrol},
	{Loot_BACKPACK,		1,		DZ_BP_Assault},
	
	//Items
	//{Loot_MAGAZINE,		5,		ItemAntibacterialWipe},
	{Loot_MAGAZINE,		5,		ItemPainkiller},
	
	//Groups
	{Loot_GROUP,		10,		Trash},
	{Loot_GROUP,		8,		Generic},
	{Loot_GROUP,		5,		AmmoCivilian},
	{Loot_GROUP,		2,		AttachmentsGeneric}
};