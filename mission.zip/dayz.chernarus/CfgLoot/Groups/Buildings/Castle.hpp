Castle[] =
{
	//Tools
	{Loot_WEAPON,		1,		ItemKnife},
	{Loot_WEAPON,		1,		ItemMap},
	{Loot_WEAPON,		1,		ItemCompass},
	{Loot_WEAPON,		2,		ItemFlashlight},
	//{Loot_WEAPON,		1,		ItemPickaxe},
	//{Loot_WEAPON,		2,		ItemPickaxeBroken},
	//{Loot_WEAPON,		2,		ItemShovel},
//	{Loot_WEAPON,		1,		ItemHatchet},
	{Loot_WEAPON,		1,		CZ550_DZ},
	{Loot_VEHICLE,		1,		WeaponHolder_ItemHatchet},
	{Loot_WEAPON,		6,		Winchester1866_DZ},
	{Loot_WEAPON,		2,		LeeEnfield_DZ},
	//Weapons
	{Loot_WEAPON,		2,		Mosin_DZ},
	
	//Backpacks
	{Loot_BACKPACK,		2,		DZ_ALICE_Pack_EP1},
	
	//Items
//	{Loot_MAGAZINE,		4,		ItemSandbag},
//	{Loot_MAGAZINE,		1,		equip_Crossbow_Kit}, //not functional yet
	{Loot_MAGAZINE,		3,		equip_rope},
	{Loot_MAGAZINE,		1,		PartWoodPile},
//	{Loot_MAGAZINE,		2,		ItemPadlock},
	{Loot_MAGAZINE,		1,		ItemTent},
//	{Loot_MAGAZINE,		1,		ItemCamoNet},
	
	//Groups
	{Loot_GROUP,		1,		AmmoCivilian},
//	{Loot_GROUP,		3,		Trash},
	{Loot_GROUP,		2,		AttachmentsGeneric},
	{Loot_GROUP,		5,		Generic},
	{Loot_GROUP,		1,		Matchbox},
	{Loot_GROUP,		5,		Consumable}
};