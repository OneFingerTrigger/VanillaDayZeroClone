Toilet[] =
{
	{Loot_WEAPON,		1,		Item5Matchbox},
	{Loot_WEAPON,		2,		ItemFlashlight},
	//{Loot_MAGAZINE,		2,		equip_rag},
	{Loot_MAGAZINE,		3,		TrashJackDaniels},
	//{Loot_MAGAZINE,		8,		ItemTrashToiletpaper}
};