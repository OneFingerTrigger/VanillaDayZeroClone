Hunting[] =
{
	//Weapons
	{Loot_WEAPON,		3,		Crossbow_DZ},
	{Loot_WEAPON,		4,		CZ550_DZ},
	{Loot_WEAPON,		8,		MR43_DZ},
	{Loot_WEAPON,		6,		Winchester1866_DZ},
	{Loot_WEAPON,		2,		LeeEnfield_DZ},
	{Loot_WEAPON,		2,		Mosin_DZ},
	
	//Tools
	{Loot_WEAPON,		4,		ItemMachete},
	{Loot_WEAPON,		6,		ItemMap},
	{Loot_WEAPON,		6,		ItemFlashlight},
	{Loot_WEAPON,		7,		ItemKnife},
	{Loot_WEAPON,		2,		ItemCompass},
	
	//Backpacks
	{Loot_BACKPACK,		3,		DZ_BP_Assault},
	{Loot_BACKPACK,		2,		DZ_BP_Survival},
	{Loot_BACKPACK,		1,		DZ_BP_Alice},
	
	//Other
	{Loot_MAGAZINE,		2,		ItemTent},
	{Loot_MAGAZINE,		1,		ItemDomeTent},
	//{Loot_MAGAZINE,		3,		TrapBear},
	//{Loot_MAGAZINE,		3,		12Rnd_Quiver_Wood},
	//{Loot_MAGAZINE,		2,		1Rnd_Bolt_Tranquilizer},
	//{Loot_MAGAZINE,		1,		1Rnd_Bolt_Explosive},
	
	{Loot_PILE,			10,		AmmoCivilian, 1, 3},
	{Loot_PILE,			10,		Consumable, 1, 3},
	{Loot_GROUP,		7,		Matchbox},
	{Loot_GROUP,		10,		Generic}
};