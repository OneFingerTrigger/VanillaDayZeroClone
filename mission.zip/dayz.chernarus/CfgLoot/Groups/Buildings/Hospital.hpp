Hospital[] =
{
	{Loot_PILE,			8,		MedicalLow, 1, 3},
	{Loot_PILE,			5,		MedicalHigh, 1, 2},
	
	{Loot_CONTAINER,	1,		DZ_MedBox, MedicalBox, 8, 16}
};