Farm[] =
{
	//Weapons
	{Loot_WEAPON,		5,		MR43_DZ},
	{Loot_WEAPON,		4,		Winchester1866_DZ},
	{Loot_WEAPON,		3,		LeeEnfield_DZ},
	{Loot_WEAPON,		3,		Mosin_DZ},
	{Loot_WEAPON,		2,		CZ550_DZ},
	{Loot_WEAPON,		2,		Crossbow_DZ},
	
	//Tools
	{Loot_WEAPON,		2,		ItemMachete},
//	{Loot_WEAPON,		2,		ItemHatchet},
	{Loot_VEHICLE,		2,		WeaponHolder_ItemHatchet},
	{Loot_WEAPON,		5,		ItemKnife},
	
	//Items
	{Loot_MAGAZINE,		4,		ItemSandbag},
	//{Loot_MAGAZINE,		1,		TrapBear},
	{Loot_MAGAZINE,		8,		PartWoodPile},
	//{Loot_MAGAZINE,		3,		equip_rope},
	//{Loot_MAGAZINE,		3,		equip_duct_tape},
	{Loot_MAGAZINE,		3,		equip_nails},
	//{Loot_MAGAZINE,		4,		equip_string},
	//{Loot_MAGAZINE,		2,		equip_lever},
	
	//Groups
	{Loot_GROUP,		10,		Trash},
	{Loot_GROUP,		15,		AmmoCivilian},
	{Loot_GROUP,		3,		AttachmentsGeneric},
	{Loot_GROUP,		8,		Consumable},
	{Loot_GROUP,		4,		Matchbox},
	{Loot_GROUP,		3,		JerryCan},
	{Loot_GROUP,		4,		FuelCan},
	{Loot_GROUP,		8,		Generic}
};