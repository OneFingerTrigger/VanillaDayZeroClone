ResidentialRuins[] =
{
	//{Loot_MAGAZINE,		10,		ItemLog},
	//{Loot_MAGAZINE,		10,		ItemStone},
	//{Loot_MAGAZINE,		7,		equip_metal_sheet_rusted},
	{Loot_GROUP,		4,		Trash},
	{Loot_GROUP,		3,		AttachmentsGeneric}
};
