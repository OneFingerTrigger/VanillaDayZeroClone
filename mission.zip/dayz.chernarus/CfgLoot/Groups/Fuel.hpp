JerryCan[] =
{
	{Loot_MAGAZINE,		1,		ItemJerryCan},
	{Loot_MAGAZINE,		1,		ItemJerryCanEmpty}
};
 
FuelCan[] =
{
	{Loot_MAGAZINE,		1,		ItemFuelcan},
	{Loot_MAGAZINE,		1,		ItemFuelcanEmpty}
}; 