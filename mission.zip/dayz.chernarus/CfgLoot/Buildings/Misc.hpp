class Land_HouseV_2I : Default
{
	maxRoaming = 3;
};

class Land_Ind_Shed_02_main : Default
{
	zombieChance = 0.3;
	maxRoaming = 3;
};