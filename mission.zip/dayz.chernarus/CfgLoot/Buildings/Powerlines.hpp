class Land_sloup_vn : Default
{
	lootChance = 0.05;
	lootPos[] = {{-0.24,-0.12,-8.05}};
	lootGroup = Powerlines;
};