class Land_Toilet : Default
{
	zombieChance = 0;
	minRoaming = 0;
	maxRoaming = 0;
	zedPos[] = {{-0.00732422,0.293945,-1.06848}};
	lootChance = 0.4;
	lootPos[] = {{-0.00732422,0.293945,-1.06848}};
	lootGroup = Toilet;
};